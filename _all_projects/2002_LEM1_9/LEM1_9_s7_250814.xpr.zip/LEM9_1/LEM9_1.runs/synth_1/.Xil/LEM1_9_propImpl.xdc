set_property SRC_FILE_INFO {cfile:C:/_jcb_uP/_2025/LEM/LEM1_9/boolean-clk.xdc rfile:../../../../boolean-clk.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:2 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict {PACKAGE_PIN F14 IOSTANDARD LVCMOS33} [get_ports {clk}]
