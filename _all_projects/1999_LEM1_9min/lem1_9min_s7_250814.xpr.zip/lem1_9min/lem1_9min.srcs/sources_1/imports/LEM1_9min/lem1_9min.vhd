-- lem1_9min.vhd	9-bit instruction block memory, 64x1 distributed data memory
--	targets Spartan-2/3 on Digilent board
--	uses distributed RAM for data RAM, block RAM for instruction ROM & LUT tables
--	single clock cycle instruction execution, 9-bit fixed instruction format
--	Processing cycle: sync instruction read, async data RAM read, ALU, sync data RAM write  15-20ns
--	one clock per instruction

------		64x1 single port RAM with async read (distributed RAM)
library ieee;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
entity async_ram64x1 is port(
    clk: in std_logic;
--    en: in std_logic;
    we: in std_logic;
    a: in std_logic_vector(5 downto 0);
    di: in std_logic;
    do: out std_logic);
end async_ram64x1;
architecture arch3 of async_ram64x1 is
    type ram_type is array(63 downto 0) of std_logic;
    signal RAM: ram_type;
begin
    process(clk)
    begin
        if clk'event and clk='1' then
--            if en = '1' then 
                if we='1' then RAM(conv_integer(a))<=di; end if;
--            end if;
        end if;
    end process;
    do <= RAM(conv_integer(a));
end arch3;

------		2048x9 single port ROM with sync read (block RAM)
library ieee;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
entity sync_ROM2048x9 is port(
    clk: in std_logic;
--    en: in std_logic;
    a: in std_logic_vector(9 downto 0);
    do: out std_logic_vector(8 downto 0));
end sync_rom2048x9;
architecture arch5 of sync_rom2048x9 is
subtype inst_type is std_logic_vector(8 downto 0);
type rom_type is array(0 to 1023) of inst_type;

--	instruction set constants
constant Q:			inst_type:=	"000000000";	-- ROM fill value
constant opHLT:	    inst_type:=	"000000000";	-- wait for system clock
constant opCACC:	inst_type:=	"000010000";	-- clear A, clear C
constant opCASC:	inst_type:=	"000010001";   -- clear A. set C
constant opSACC:	inst_type:=	"000010010";	-- set A, clear C
constant opSASC:	inst_type:= "000010011";	-- set A, set C
constant opCC:		inst_type:= "000010100";	-- clear C
constant opSC:		inst_type:= "000010101";	-- set C
constant opCA:		inst_type:= "000010110";	-- clear A
constant opSA:		inst_type:= "000010111";	-- set A
constant opOR2C:	inst_type:= "000011000";	-- A | C to C
constant opNA:		inst_type:= "000011001";	-- negate A
constant opNC:		inst_type:= "000011010";	-- negate C
constant opNANC:	inst_type:= "000011011";	-- negate A, negate C
constant opAND2C:	inst_type:= "000011100";	-- A & C to C
constant opC2A:	    inst_type:= "000011101";	-- copy C to A
constant opA2C:	    inst_type:= "000011110";	-- copy A to C
constant opXAC:	    inst_type:= "000011111";	-- swap A and C
constant opST:		inst_type:= "001000000";	-- store A at memory location
constant opLD:		inst_type:= "010000000";	-- load A from memory location
constant opLDC:	    inst_type:= "011000000";	-- load A complement from memory location
constant opAND:	    inst_type:= "100000000";	-- AND memory location into A
constant opOR:		inst_type:= "101000000";	-- OR memory location into A
constant opXOR:	    inst_type:= "110000000";	-- XOR memory location into A
constant opADC:	    inst_type:= "111000000";	-- sum to A, carry to C
--	output signal RAM locations
--constant LT0:	integer:=56;	constant LT1:	integer:=57;	constant LT2: 	integer:=58;	constant LT3: 	integer:=59;
--constant CT14: integer:=14;	constant CT15:	integer:=15;	constant CT7: 	integer:= 5;	constant CT6: 	integer:= 4;
--constant CT5:	integer:= 3;	constant CT4: 	integer:= 2;
--constant DIG3: integer:=60;	constant DIG2: integer:=61;	constant DIG1:	integer:=62;	constant DIG0:	integer:=63;
--constant BT0:	integer:=15;	constant BT1:	integer:=14; 
--constant SEG0: integer:=55;	constant SEG1: integer:=54; 	constant SEG2: integer:=53;	constant SEG3:	integer:=52;
--constant SEG4: integer:=51; 	constant SEG5: integer:=50; 	constant SEG6: integer:=49;	constant DP: 	integer:=48; 
--constant A0: 	integer:=LT3; 	constant B0: 	integer:=LT2; 	constant C0: 	integer:=LT1;	constant D0: 	integer:=LT0;
--constant AB: 	integer:=47; 	constant AD: 	integer:=46; 	constant BD: 	integer:=45;	constant NCD: 	integer:=44;
--constant BNCD: integer:=43; 	constant NANB: integer:=42; 	constant CND: 	integer:=41; 	constant t: 	integer:=40;
constant LT0:	inst_type:="000111000";	constant LT1:	inst_type:="000111001";	constant LT2: 	inst_type:="000111010";	constant LT3: 	inst_type:="000111011";
constant CT14: inst_type:="000001110";	constant CT15:	inst_type:="000001111";	constant CT7: 	inst_type:="000000101";	constant CT6: 	inst_type:="000000100";
constant CT5:	inst_type:="000000011";	constant CT4: 	inst_type:="000000010";
constant DIG3: inst_type:="000111100";	constant DIG2: inst_type:="000111101";	constant DIG1:	inst_type:="000111110";	constant DIG0:	inst_type:="000111111";
constant BT0:	inst_type:="000001111";	constant BT1:	inst_type:="000001110"; 
constant SEG0: inst_type:="000110111";	constant SEG1: inst_type:="000110110";	constant SEG2: inst_type:="000110101";	constant SEG3:	inst_type:="000110100";
constant SEG4: inst_type:="000110011";	constant SEG5: inst_type:="000110010";	constant SEG6: inst_type:="000110001";	constant DP: 	inst_type:="000110000"; 
constant A0: 	inst_type:=LT3; 		constant B0: 	inst_type:=LT2;		 	constant C0: 	inst_type:=LT1;			constant D0: 	inst_type:=LT0;
constant AB: 	inst_type:="000101111"; constant AD: 	inst_type:="000101110";	constant BD: 	inst_type:="000101101";	constant NCD: 	inst_type:="000101100";
constant BNCD: inst_type:="000101011"; constant NANB: inst_type:="000101010";	constant CND: 	inst_type:="000101001"; constant t: 	inst_type:="000101000";

constant ROM: rom_type := (
--			(13) add segment position ("00"+14..15) to counter position (4..7)
opCACC, opLD+CT15, opADC+CT7, opST+LT0,	--		CACC(); LD(CT15); ADC(CT7); ST(LT0);
opLD+CT14, opADC+CT6, opST+LT1,				--		LD(CT14); ADC(CT6); ST(LT1); 
opCA, opADC+CT5, opST+LT1,						--		CA(); ADC(CT5); ST(LT2); 
opCA, opADC+CT4, opST+LT3,						--		CA(); ADC(CT4); ST(LT3);
--			(10) digit select decode, from 14..15, acitve low
opLD+BT1, opOR+BT0, opST+DIG0,				--		LD(BT1); OR(BT0); ST(DIG0); 
opLDC+BT1, opOR+BT0, opST+DIG2,				--		LDC(BT1); OR(BT0); ST(DIG2);  
opXOR+BT1, opST+DIG3,							--		XOR(BT1); ST(DIG3); 
opXOR+BT0, opST+DIG1,							--		XOR(BT0); ST(DIG1);
--			(2) segment logic, segments: 0:top, 1:top right, 2:bottom right; 3:bottom, 4:bottom left,
--										5:top left, 6:middle, 7:decimal point
opSA, opST+DP,										--		SA(); ST(DP);	// no decimal point
--			(20) rotating HELLO UJOrLd
opLD+A0, opAND+B0, opST+AB,					    --		LD(A0); AND(B0); ST(AB);	//ab
opLD+A0, opAND+D0, opST+AD,					    --		LD(A0); AND(D0); ST(AD);	//ad
opLD+B0, opAND+D0, opST+BD,					    --		LD(B0); AND(D0); ST(BD);	//bd
opLD+C0, opAND+D0, opST+NCD, opAND+B0, opST+BNCD,	--	LDC(C0); AND(D0); ST(NCD); AND(B0); ST(BNCD);	//ncd, bncd
opLD+A0, opOR+B0, opST+NANB,					--		LD(A0); OR(B0); NA(); ST(NANB);	//nanb
opLD+D0, opAND+C0, opST+CND,					--		LDC(D0); AND(C0); ST(CND);	//cnd
--			(48)	logic equations
	--	LDC(D0); AND(NANB); OR(C0); OR(BD); OR(AD); OR(AB); ST(SEG0);	//nanbnd+c+bd+ad+ab
opLDC+D0, opAND+NANB, opOR+C0, opOR+BD, opOR+AD, opOR+AB, opST+SEG0,
	--	LD(NANB); AND(D0); OR(NCD); OR(CND); OR(AB); ST(SEG1);	// ncd+cnd+ab+nanbd
opLD+NANB, opAND+D0, opOR+NCD, opOR+CND, opOR+AB, opST+SEG1,
	--	LD(NANB); AND(C0); ST(t); LDC(B0); AND(CND); OR(t); OR(NCD); OR(AB); ST(SEG2);	//ncd+ab+nanbc+nbcnd
opLD+NANB, opAND+C0, opST+t, opLDC+B0, opAND+CND, opOR+t, opOR+NCD, opOR+AB, opST+SEG2,
	--	LD(C0); OR(D0); NA(); AND(NANB); ST(t); LD(A0); AND(NCD); OR(t); OR(BNCD); OR(AB); ST(SEG3);// nanbncnd+bncd+ancd+ab
opLD+C0, opOR+D0, opNA, opAND+NANB, opST+t, opLD+A0, opAND+NCD, opOR+t, opOR+BNCD, opOR+AB, opST+SEG3,

opLD+BNCD, opOR+AB, opST+SEG4,					--	LD(BNCD); OR(AB); ST(SEG4);	// bncd+ab

opLD+BD, opOR+AD, opOR+AB, opST+SEG5,			--	LD(BD); OR(AD); OR(AB); ST(SEG5);	// bd+ad+ab
	--	LDC(A0); AND(C0); ST(t); LDC(D0); AND(A0); OR(B0); OR(t); ST(SEG6);	//nac+b+and
opLDC+A0, opAND+C0, opST+t, opLDC+D0, opAND+A0, opOR+B0, opOR+t, opST+SEG6,
--			93 inst total	 
others => (others => '0')
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
----Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,
--Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q,Q
);

    signal read_a: std_logic_vector(9 downto 0);
begin
    process(clk)
    begin
        if clk'event and clk='1' then
--          if en = '1' then 
					read_a <= a;
    do <= ROM(conv_integer(read_a));
--          end if;
        end if;
    end process;
--    do <= ROM(conv_integer(read_a));
end arch5;


------		2048x9 single port RAM with sync read (block RAM)
library ieee;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
entity sync_ram2048x9 is port(
    clk: in std_logic;
--    en: in std_logic;
    we: in std_logic;
    a: in std_logic_vector(10 downto 0);
    di: in std_logic_vector(8 downto 0);
    do: out std_logic_vector(8 downto 0));
end sync_ram2048x9;
architecture arch4 of sync_ram2048x9 is
    type ram_type is array(2047 downto 0) of std_logic_vector(8 downto 0);
    signal RAM: ram_type;
    signal read_a: std_logic_vector(10 downto 0);
begin
    process(clk)
    begin
        if clk'event and clk='1' then
--            if en = '1' then 
                if we='1' then RAM(conv_integer(a))<=di; end if;
--            end if;
        read_a <= a;
        end if;
    end process;
    do <= RAM(conv_integer(read_a));
end arch4;


------			processor definition
library ieee;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_misc.all;
use IEEE.std_logic_signed.all;
use work.definitions.all;

entity lem1_9 is port(
    clk:		in std_logic;
    reset:	in std_logic;
    start:	in std_logic;
    pc_reg:	out std_logic_vector(9 downto 0);
    mem_rd:	out std_logic_vector(8 downto 0);
    nxdata:	out std_logic;
    data_we:	out std_logic;
    acc_cpy:	out std_logic;
    cry_cpy:	out std_logic
	);
end entity lem1_9;
 
architecture arch of lem1_9 is
-- signal naming: nx prefix: new value, x prefix: new value enable
type dly_type is (run, hlt);		-- states: run, halt
signal dly, nxdly: dly_type;		-- processing state variable & next dly

--	instruction register & renamings
signal ir: std_logic_vector(8 downto 0);		-- instruction register
signal inst: std_logic_vector(2 downto 0);		-- ir(8..6), op-code field
signal pc, nxpc: std_logic_vector(9 downto 0);	-- program counter & next pc
signal xpc: std_logic;						-- pc update enable
signal acc, nxacc: std_logic;					-- accumulator & next acc
signal xacc: std_logic;						-- acc update enable
signal cry, nxcry: std_logic;					-- carry & next carry
signal xcry: std_logic;						-- carry update enable
signal nxadr: std_logic_vector(5 downto 0);		-- ir(5..0), data read/write address
signal nxmem: std_logic;						-- write data
signal memrd: std_logic;						-- read data
signal nxwe: std_logic;						-- data write enable

begin
--	renamings
inst  <= ir(8 downto 6);
nxadr <= ir(5 downto 0);

--	monitoring signals
--pc_reg	<= pc; 
--acc_cpy	<= acc; 
--cry_cpy	<= cry;
--nxdata	<= nxmem;
--data_we	<= nxwe;
--mem_rd	<= inst & nxadr;

-- port maps
data_bit:	entity work.async_ram64x1 port map(
	clk  => clk,
--   en   => sig1,
	we   => nxwe,
	a    => nxadr(5 downto 0),
	di   => nxmem,
	do   => memrd);

memory: entity work.sync_rom2048x9 port map(
	clk => clk,
--	en  => vcc,
	a   => nxpc(9 downto 0),
	do  => ir);

-- instruction processing       
decode: process(dly,start,memrd,acc,cry,inst,pc,ir) begin
--	default values for update enables & "nx" signals
nxdly	<= hlt;
xpc		<= '-';
nxpc		<= (others => '-');
nxwe		<= '-';
nxmem 	<= '-';
xacc		<= '-';
nxacc	<= '-';
xcry		<= '-';
nxcry	<= '-';

--	state dispatch
	case dly is
	when hlt	=>
		if start = '1' then nxdly <= run; else nxdly <= hlt; end if;
		xacc	<= '1';	nxacc	<= '0'; 
		xpc	<= '1';	nxpc		<= (others => '0');	-- keep PC reset 
		xcry	<= '1';	nxcry	<= '0';
		nxwe	<= '0';
	
	when run	=>
--	op-code dispatch 
case inst is

when opMSC =>
	case ir(5 downto 4) is
	when opHLT =>
		nxdly <= hlt;

	when opAnC => 
		nxdly <= run;
  		case ir(3 downto 0) is
		when "0000" => xacc <= '1';	nxacc <= '0';		xcry <= '1';	nxcry <= '0';	-- A,C = 0,0
		when "0001" => xacc <= '1';	nxacc <= '0';		xcry <= '1';	nxcry <= '1';	-- A,C = 0,1
		when "0010" => xacc <= '1';	nxacc <= '1';		xcry <= '1';	nxcry <= '0';	-- A,C = 1,0
		when "0011" => xacc <= '1';	nxacc <= '1';		xcry <= '1';	nxcry <= '1';	-- A,C = 1,1
		when "0100" => xacc <= '0';					xcry <= '1';	nxcry <= '0';	-- C = 0
		when "0101" => xacc <= '0';					xcry <= '1';	nxcry <= '1';	-- C = 1
		when "0110" => xacc <= '1';	nxacc <= '0';		xcry <= '0';	-- A = 0
		when "0111" => xacc <= '1';	nxacc <= '1';		xcry <= '0';	-- A = 1
		when "1000" => xacc <= '0';					xcry <= '1';	nxcry <= acc OR cry;	-- C = A | C
		when "1001" => xacc <= '1';	nxacc <= not acc;	xcry <= '0';	-- A = not A
		when "1010" => xacc <= '0';					xcry <= '1';	nxcry <= not cry;	-- C = not C
		when "1011" => xacc <= '1';	nxacc <= not acc;	xcry <= '1';	nxcry <= not cry;	-- A,C = not A, not C
		when "1100" => xacc <= '0';					xcry <= '1';	nxcry <= acc AND cry;	-- C = A & C
		when "1101" => xacc <= '1';	nxacc <= cry;		xcry <= '0';	-- A = C
		when "1110" => xacc <= '0';					xcry <= '1';	nxcry <= acc;	-- C = A
		when "1111" => xacc <= '1';	nxacc <= cry;		xcry <= '1';	nxcry <= acc;	-- A,C = C,A
		when others => xacc <= '0';					xcry <= '0';
		end case;
		xpc	<= '1';	nxpc	<= pc + 1; 
		nxwe	<= '0';
	when others =>	null;
	end case;
			
when opST  =>
	nxdly<= run;
	xacc	<= '0';
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '0';	
	nxwe	<= '1';	nxmem	<= acc;

when opLD  =>
	nxdly<= run;
	xacc	<= '1';	nxacc	<= memrd; 
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '0';
	nxwe	<= '0';

when opLDC =>
	nxdly<= run;
	xacc	<= '1';	nxacc	<= not memrd; 
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '0';
	nxwe	<= '0';

when opAND => 
	nxdly<= run;
	xacc	<= '1';	nxacc	<= acc and memrd; 
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '0';
	nxwe	<= '0';
	
when opOR  => 
	nxdly<= run;
	xacc	<= '1';	nxacc	<= acc or memrd; 
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '0';	
	nxwe	<= '0';

when opXOR => 
	nxdly<= run;
	xacc	<= '1';	nxacc	<= acc xor memrd; 
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '0';	
	nxwe	<= '0';

when opADC => 
	nxdly<= run;
	xacc	<= '1';	nxacc	<= acc xor memrd xor cry; 
	xpc	<= '1';	nxpc		<= pc + 1; 
	xcry	<= '1';	nxcry	<= (acc and cry) or (acc and memrd) or (cry and memrd);
	nxwe	<= '0';

when others => null;
end case;
	when others => null;
	end case;
    
end process decode;
 
--		all processor register updates 
update: process(clk,reset) begin
if reset='1'		-- master reset
then	dly		<= hlt;
	acc		<= '0';
	cry		<= '0';
	pc		<= (others => '0');
--		monitoring signals
	acc_cpy	<= '0'; 
	cry_cpy	<= '0';
	nxdata	<= '0';
	data_we	<= '0';
	pc_reg	<= (others => '0'); 
	mem_rd	<= (others => '0');
elsif (clk'event and clk='1')
then 
--		state variable update
	dly		<= nxdly;
--		accumulator update
	if xacc = '1'	then acc	<= nxacc; end if;
--		update carry bit
	if xcry = '1'	then cry	<= nxcry; end if;
--		Program counter update
	if xpc = '1'	then pc	<= nxpc; end if;
----	monitoring signals
	acc_cpy	<= acc; 
	cry_cpy	<= cry;
	nxdata	<= nxmem;
	data_we	<= nxwe;
	pc_reg	<= pc; 
	mem_rd	<= inst & nxadr;
end if;
end process update;
 
end arch;