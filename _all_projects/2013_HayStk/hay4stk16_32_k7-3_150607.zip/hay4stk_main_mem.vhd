----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- 
-- Create Date:		             
-- Design Name:		                                        
-- Module Name:		    hay4stk_main_mem.vhd
-- Project Name:		hay4stk16_32
-- Target Devices: 
-- Tool versions: 
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
--USE hay4stk.hay4stk_main_mem_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;
USE work.hay4stk_main_mem_pkg;

entity hay4stk_main_mem is
generic(
--	INIT_FILENAME		: string := "/test.bin"
	INIT_FILENAME		: string := "test.bin"
);
port
(
	reset			 	: in std_logic; --Sync Reset
	clk					: in std_logic; --Clk input

--	main_mem_addr_in	: in  hay4stk_main_mem_addr_type;			--
	main_mem_in  		: in  hay4stk_main_mem_inputs_rtype;		--
	main_mem_out		: out hay4stk_main_mem_outputs_rtype 		--
);
end hay4stk_main_mem;
    
architecture RTL of hay4stk_main_mem is
	
--	signal BRAM_instance 		: hay4stk_main_mem_type := hay4stk_main_mem_pkg.hay4stk_InitMainMemFromFile(INIT_FILENAME);
	signal BRAM_instance 		: hay4stk_main_mem_type := hay4stk_main_mem_pkg.hay4stk_InitMainMem;
	signal DATA_MEM		 		: hay4stk_main_data_mem_type;
	
	signal dout 				: hay4stk_main_mem_data_type;
	
begin

	---------------------------------------------
	--BlockRAM inference
	BLOCK_RAM_PROC:process(clk)
	begin
		if rising_edge(clk) then
		
			--High 16-bits
			if main_mem_in.we_hi = '1' then
				BRAM_instance( to_integer(unsigned(main_mem_in.addr)) ) (hay4stk_main_mem_data_type'high downto hay4stk_main_mem_data_type'high - hay4stk_main_mem_hi_data_type'length + 1)
														<= main_mem_in.din(hay4stk_main_mem_data_type'high downto hay4stk_main_mem_data_type'high - hay4stk_main_mem_hi_data_type'length + 1);
			end if;
			
			--Low 16-bits
			if main_mem_in.we_lo = '1' then
				BRAM_instance( to_integer(unsigned(main_mem_in.addr)) ) 	(hay4stk_main_mem_data_type'low + hay4stk_main_mem_hi_data_type'length - 1 downto hay4stk_main_mem_data_type'low)
														<= main_mem_in.din(hay4stk_main_mem_data_type'low + hay4stk_main_mem_hi_data_type'length - 1 downto hay4stk_main_mem_data_type'low);
			end if;
			
			dout <= BRAM_instance( to_integer(unsigned(main_mem_in.addr)) );
			
			--Reset of output is not needed!
			
		end if;
	end process;
	
	main_mem_out.dout_hi <= dout(dout'high downto dout'high-hay4stk_main_mem_hi_data_type'length+1);
	main_mem_out.dout_lo <= dout(dout'low+hay4stk_main_mem_lo_data_type'length-1 downto dout'low);
	---------------------------------------------
	
	--Simulation only constructs
	--synthesis translate_off
	
	DATA_MEM_PROC:process(BRAM_instance)
	variable i : integer;
	begin
		i := BRAM_instance'low;
		for j in BRAM_instance'low to BRAM_instance'high loop
			--Low Part
			DATA_MEM(i) 	<= BRAM_instance(j)(dout'low+hay4stk_main_mem_lo_data_type'length-1 downto dout'low);
			i:=i+1;
			--High Part
			DATA_MEM(i) 	<= BRAM_instance(j)(dout'high downto dout'high-hay4stk_main_mem_hi_data_type'length+1);
			i:=i+1;
		end loop;
	end process;
	
	--synthesis translate_on
	
end RTL;