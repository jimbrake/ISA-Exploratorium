----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- 
-- Create Date:		             
-- Design Name:		                                        
-- Module Name:		    hay4stk_tb.vhd
-- Project Name:		hay4stk16_32
-- Target Devices: 
-- Tool versions: 
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;

--***********************************Entity Declaration--*************************************************

entity hay4stk_tb is
end entity hay4stk_tb;
    
architecture test_hay4stk_tb of hay4stk_tb is
	
	signal	reset			: std_logic; --Sync Reset
	signal	external_input	: hay4stk_operand_data_type; --External Data Input
	signal	DID_out_regd		: hay4stk_operand_data_type;
	signal 	ALU_ctrl_cpy		: hay4stk_alu_ctrl_rtype; 	--
	signal 	ALU_Op1_Reg_cpy		: hay4stk_operand_data_type; 	--
	signal 	ALU_Op2_Reg_cpy		: hay4stk_operand_data_type;
	signal  to_main_mem_cpy		: hay4stk_main_mem_inputs_rtype;
	signal  from_main_mem_cpy	: hay4stk_main_mem_outputs_rtype;
	
	--------------------------	
	-- Clock period definitions
	constant clk_period  	: time := 10 ns;
	signal	 clk 			: std_logic;

begin

	-- Clock process definitions
	clk_process :process
	begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
	end process;

	
	Inst_hay4stk_top_dut : entity work.hay4stk_top
	-- generic map(
		-- 			=> 
	-- )
	port map(
		reset					=>	reset,
		clk						=>	clk,
		
		external_input			=>	external_input,
		DID_out_regd			=>	DID_out_regd,
		ALU_ctrl_cpy			=>	ALU_ctrl_cpy,
		ALU_Op1_Reg_cpy			=>	ALU_Op1_Reg_cpy,
		ALU_Op2_Reg_cpy			=>	ALU_Op2_Reg_cpy,
		to_main_mem_cpy  		=>  to_main_mem_cpy,
		from_main_mem_cpy		=>  from_main_mem_cpy
	);
	
	external_input <= (others => '0');
		
	RESET_PROC:process
	begin
		reset <= '1';
		wait for 20 ns;
		reset <= '0';
	wait;
	end process;
	
end test_hay4stk_tb;