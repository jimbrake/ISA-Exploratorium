----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- 
-- Create Date:		             
-- Design Name:		                                        
-- Module Name:		    hay4stk_control.vhd
-- Project Name:		hay4stk16_32
-- Target Devices: 
-- Tool versions: 
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
--USE hay4stk.hay4stk_ctrl_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;
USE work.hay4stk_ctrl_pkg.ALL;

entity hay4stk_control is
port
(
	reset			 	: in std_logic; --Sync Reset
	clk					: in std_logic; --Clk input
	
	from_main_mem  		: in  hay4stk_main_mem_outputs_rtype;	--
	to_main_mem			: out hay4stk_main_mem_inputs_rtype; 	--
	
	Op1_reg_out			: out  hay4stk_operand_data_type;	--
	Op2_reg_out			: out  hay4stk_operand_data_type;	--
	N_reg_out			: out  hay4stk_operand_data_type;	--
	
	external_input		: in  hay4stk_operand_data_type;	--
	
--	--Address Bus
--	addr_bus_out		: out hay4stk_address_bus_type;		--hay4stk address bus output
	
	--ALU Interface
	alu_did_mux_in		: in  hay4stk_operand_data_type;	--ALU DID Mux Input
	alu_Cout			: in  std_logic;					--ALU Carry Output
	alu_Overflow		: in  std_logic;					--ALU Overflow signal
	alu_ctrl_out		: out hay4stk_alu_ctrl_rtype; 		--ALU Control Signals
	
	--Address Generator RAM Interface
	addr_gen_data_in	: in  hay4stk_Addrgen_RAM_data_type;	--Address input from Address Generator
	addr_gen_ctrl_out	: out hay4stk_addrgen_ctrl_rtype 		--
);
end hay4stk_control;
    
architecture RTL of hay4stk_control is
	
	signal IR_reg					: hay4stk_instruction_rtype;
	signal ALU_ctrl_reg				: hay4stk_alu_ctrl_rtype;
	
	alias N_bits					: hay4stk_operand_data_type is from_main_mem.dout_lo;
	
	signal state,next_state			: hay4stk_control_machine_state_type;
	
	signal AddrGen_RdAddrTemp		: hay4stk_addrgen_ctrl_addrsel_type; --Used for PC/Data addressing (PC goes in multiples of 2)
	
	signal N_Reg					: hay4stk_operand_data_type;
	signal Op1_Reg					: hay4stk_operand_data_type;
	signal Op2_Reg					: hay4stk_operand_data_type;
	---
	signal Operand_mux_data			: hay4stk_operand_data_type;

	signal addr_gen_to_main_mem		: hay4stk_main_mem_addr_type;
	alias addr_gen_out_A0			: std_logic is addr_gen_data_in(addr_gen_data_in'low);
	alias addr_gen_out_A15			: std_logic is addr_gen_data_in(addr_gen_data_in'high);
	signal addr_gen_out_A0_delay	: std_logic;
	signal addr_gen_out_A15_delay	: std_logic;
	
	signal CCR_EXT_Mux_data			: hay4stk_operand_data_type;
	signal Mem_hi_lo_mux			: hay4stk_operand_data_type;
	---
	
	signal ir_reg_we_async			: std_logic;
	signal n_reg_we_async			: std_logic;
	signal alu_reg_we_async			: std_logic;
	signal ir_reg_we				: std_logic;
	signal n_reg_we					: std_logic;
	signal ALU_reg_we_pipe			: std_logic;
	signal alu_reg_we				: std_logic;
	
	signal CCR_we_async				: std_logic;
	signal op1_reg_we_async			: std_logic;
	signal op1_reg_we				: std_logic;
	signal op2_reg_we_async			: std_logic;
	signal op2_reg_we				: std_logic;
	
	signal IR_Reg_async			: hay4stk_instruction_rtype;
	
	--CCR Stuff
	signal CCR_RAM				: hay4stk_ccr_ram_type;
	signal CCR_addr_sel			: std_logic_vector(1-1 downto 0);
	signal CCR_logic			: hay4stk_ccr_slv_type;
	signal CCR_din				: hay4stk_ccr_slv_type;
	signal CCR_dout				: hay4stk_ccr_slv_type;
	signal CCR_dout_rtype		: hay4stk_ccr_rtype;
	signal CCR_we				: std_logic;
	
	signal Branch_Ctrl			: std_logic;
	
	-------------------------
	--Simulation only signals
	signal is_ALU_inst			: std_logic;
	signal is_BRANCH_inst		: std_logic;
	signal is_IMM_inst			: std_logic;
	
begin
	
	---------------------------------------------
	--Main Control State Machine (Combinational part)
	STATE_COMB_PROC:process(state,IR_reg,IR_Reg_async,branch_ctrl,addr_gen_out_A0,Op1_reg,Op2_reg)
	begin
		
		--Default state for signals so no latches are inferred:
		next_state 					<= st_reset;
		--
		IR_reg_we_async 			<= '0';
		N_reg_we_async 				<= '0'; --Register N
		Op1_reg_we_async			<= '0'; --Register Op1
		Op2_reg_we_async			<= '0'; --Register Op2
		ALU_reg_we_async			<= '0';
		CCR_we_async				<= '0';
		to_main_mem.we_hi			<= '0';
		to_main_mem.we_lo			<= '0';
		--AddrGen Defaults
		AddrGen_RdAddrTemp 					<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC;  		--Select PC
		addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC;  		--Select PC
		addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "0";   									--Do NOT write into AddrRAM
		addr_gen_ctrl_out.EAR_sel 			<= HAY4STK_ADDRGEN_CTRL_EAR_MUX_RAM;	  	--Select AddrRAM Dout
		addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR; 	--Select the output of the EAR mux
		addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX; 
		addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_1; 		--Increment PC
		addr_gen_ctrl_out.EAR_we 			<= "0";
		--
	
		case state is
		
			when st_reset  =>
				
				--Write the PC initial position to be the init value of Op2 Register (Code Vector)
				addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "1";
				addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC;			--Select PC
				addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_OP2; 	--Select Op2
				addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_0;		--Add 0
				--Go to fetch next instruction
				next_state <= st_phase5;
			
			when st_phase1  =>
			
			-- Phase 1	ALU operation & process write enables to blkRAM & to CCR
			-- read & register next instruction, register N, register op2 as N
			-- go to Phase 2, 3, 5 or 6

				--During this cycle, next instruction is out of the blockRAM and being latched into the registers
				--Finish writing result of previous instruction (if necessary, IR_reg still contains previous instruction)
			
				--Process Main Memory WE
				if hay4stk_instr_main_mem_we(IR_Reg) = '1' then
					if addr_gen_out_A0 = '0' then --Use A0 to determine which part to write
						to_main_mem.we_lo				<= '1';
					else
						to_main_mem.we_hi				<= '1';
					end if;
				end if;
				
				--Write to CCR
				CCR_we_async 							<= hay4stk_ccr_we_decode(IR_Reg);
				
				--Configure Addrgen to store SPn update if in Stack Mode (from last instruction)
				AddrGen_RdAddrTemp 						<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN;				--Select SPn
				
				if IR_reg.OpCode = HAY4STK_INSTR_OPCODE_LD_PTR then
					--Update M PTR
					addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_M_BITS;			--Select M bits
					addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_OP2;		--Select Op2 (should contain N)
					addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_0;			--0
				else
					--Update SPn-1
					addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN;			--Select SPn
					addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX;
					addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N1;			--Subtract 1
				end if;
				
				if hay4stk_instr_is_alu(IR_reg) then
				
					--ALU Instructions have different options
					addr_gen_ctrl_out.EAR_sel 			<= HAY4STK_ADDRGEN_CTRL_EAR_MUX_RAM;	  		--Select AddrRAM Dout
					addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR; 		--Select the output of the EAR mux
					
					--If m=n save result in M(SPn-1)
					if (IR_reg.M_bits(1 downto 0) = IR_reg.LL_bits) then
						--Save result in SPn-1
						addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_ADDR_ALU; 	--Select the output of the Address ALU
					end if;
					
					--If replace operation store result (replace Op2) instead of SPn (Op1)
					if IR_reg.R_bits = "1" AND (IR_reg.OpCode /= HAY4STK_INSTR_OPCODE_CALL) then
						--Select EAR Reg
						addr_gen_ctrl_out.EAR_sel 			<= HAY4STK_ADDRGEN_CTRL_EAR_MUX_EAR;	  		--Select EAR Register
					end if;
				
				else
					--None ALU instructions save result in SPn Address always
					addr_gen_ctrl_out.EAR_sel 			<= HAY4STK_ADDRGEN_CTRL_EAR_MUX_RAM;	  		--Select AddrRAM Dout
					addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR; 		--Select the output of the EAR mux
				end if;
				
				if IR_reg.P_bits = "1" then
					-- if P bit set register update AddrRam
					addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "1";
					--
				else
					-- else don't update AddrRam
					addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "0";
				end if;
		
		
				next_state 							<= hay4stk_instr_decode_state_ph1(IR_Reg_async);
				
			when st_phase2 =>
				
			-- Phase 2	Post read address for SPn, set register op1 enable
			-- DECODE! instruction, register ALU controls, register blkRAM we, register CCR we
			-- if P bit set register SPn+1 to addrRAM (POP)
			-- go to Phase 3 or 5

				--IR_reg now contains the new instruction
				--DECODE!
				
				--set register op1 enable (regardless, will latch next cycle)
				Op1_reg_we_async 	<= '1';
				--

				--Configure Addrgen to read SPn of new instruction, and write SPn+1 (if P bit is set)
				AddrGen_RdAddrTemp 					<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN;			--Select SPn
				addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN;			--Select SPn
				addr_gen_ctrl_out.EAR_sel 			<= HAY4STK_ADDRGEN_CTRL_EAR_MUX_RAM;	  		--Select AddrRAM Dout
				addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX;		--Select Output of EAR Mux	
				addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_1;			--Add 1
				addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR;		--Output the SPn Address 
				addr_gen_ctrl_out.EAR_we 			<= NOT(IR_Reg.R_Bits); 							--Register SPn if R bit is clear

				if IR_reg.P_bits = "1" AND IR_reg.R_bits = "1" AND hay4stk_instr_is_alu(IR_reg) then -- if P and R bits are set register SPn+1 to addrRAM (POP functionality)
					addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "1";
				else
					addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "0";
				end if;
				
				--Decode Phase2
				next_state 							<= hay4stk_instr_decode_state_ph2(IR_reg);
				
			when st_phase3 =>
			
			-- Phase 3	Post read address for EA, set register op2 enable
			-- if T bit set register EA to addrRAM
			-- go to Phase 5

				next_state 							<= st_phase5;
			
				--set register Op2 enable (regardless, will latch next cycle)
				Op2_reg_we_async 	<= '1';
				
				if IR_reg.T_bits = "1" then
					-- if T bit set register M pointer new Addr to addrRAM
					addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "1";
				else
					-- else don't store
					addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "0";
				end if;
				
				addr_gen_ctrl_out.EAR_we 			<= "1"; --Register EAR
				
				--Configure AddrGen RAM to output M selected pointer plus N (EAR) to the Main Memory Address
				AddrGen_RdAddrTemp 					<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_M_BITS;				--Select M bits
				addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_M_BITS;				--Select M bits
				addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX;			--Select Output of EAR Mux	
				addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N;				--Add with N
				addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_ADDR_ALU;		--Output the Address ALU result to Main Memory				
				
				
				
				if IR_reg.OpCode = HAY4STK_INSTR_OPCODE_CALL AND NOT(hay4stk_instr_is_imm(IR_reg))  then
					AddrGen_RdAddrTemp 				<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC;			--Select PC
				end if;
				
				if (IR_reg.OpCode = HAY4STK_INSTR_OPCODE_RTN AND hay4stk_instr_is_imm(IR_reg)) then
					--If RTN instruction
					AddrGen_RdAddrTemp 					<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN;			--Select SPn
					addr_gen_ctrl_out.WrAddr_sel		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN;			--Select SPn
					addr_gen_ctrl_out.delta_sel			<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_1;			--Add 1
					addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR;		--Output the SPn Address 
					
					if IR_reg.P_bits = "1" then
						addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "1";
					else
						addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "0";
					end if;
					
					--Go to wait state
					next_state 							<= st_wait_Op2;
				end if;
				
			
			when st_phase4 =>
			--**UNUSED YET**
			-- Phase 4	Post read address for SP0
			-- register SP0+1 to adrRAM
			-- register op2 if enabled
			-- register op1 if enabled
			-- go to Phase 5
				next_state 								<= st_phase5;
				
			when st_phase5 =>
				
			-- Phase 5	Post read address for PC+1/PC+N
			-- register PC+1 to adrRAM
			-- register EAR, needed to capture PC before new PC in call inst
			-- register op2 if enabled
			-- register op1 if enabled
			-- go to Phase 1

				--Configure Addr Gen to fetch next instruction
				AddrGen_RdAddrTemp 					<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC;  			--Select PC
				addr_gen_ctrl_out.WrAddr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC;  			--Select PC
				addr_gen_ctrl_out.EAR_sel 			<= HAY4STK_ADDRGEN_CTRL_EAR_MUX_RAM;			--Select AddrRAM Dout (PC)
				addr_gen_ctrl_out.EAR_we 			<= "0";				  							--Do not Register EAR
				addr_gen_ctrl_out.Addrgen_mux_sel 	<= HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_ADDR_ALU; 	--Select newly calculated PC
				addr_gen_ctrl_out.addr_sel 			<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX; 	--
				
				if Branch_Ctrl = '1' OR (IR_reg.OpCode = HAY4STK_INSTR_OPCODE_CALL AND NOT(hay4stk_instr_is_imm(IR_reg))) then
					--Branch is taken or CALL instruction
					addr_gen_ctrl_out.delta_sel		<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N; 			--Increment PC in N
				else
					--Branch is not taken
					addr_gen_ctrl_out.delta_sel		<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_1; 			--Increment PC in 1
				end if;
				
				if (IR_reg.OpCode = HAY4STK_INSTR_OPCODE_RTN AND hay4stk_instr_is_imm(IR_reg)) then
					--If return instruction
					addr_gen_ctrl_out.addr_sel 		<= HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_OP2; 	--Select OP2
					addr_gen_ctrl_out.delta_sel		<= HAY4STK_ADDRGEN_CTRL_DELTA_MUX_0; 		--Do not increment
				end if;
				
				--Write new PC
				addr_gen_ctrl_out.Addrgen_RAM_wr_en	<= "1";   										
				
				--Latch instruction data into the appropriate registers
				IR_reg_we_async 					<= '1'; --Register new Instruction
				N_reg_we_async 						<= '1'; --Register N
				Op2_reg_we_async					<= '1'; --Register Op2 as N, in case of immediate instruction
				ALU_reg_we_async					<= '1'; --Register ALU Controls
				-- CCR_we_async						<= '1'; --Register CCR
				
				next_state 							<= st_phase1;

			when st_wait_Op2 =>
				
				--Wait state for Op2 when loading PC from Main Memory, always returns to phase 5
				next_state 							<= st_phase5;
				
			when others =>
			
				assert FALSE report "Fell into an unknown state" severity FAILURE;			
				next_state 							<= st_unknown_opcode;
			
		end case;

	end process;
	
	--Synchronize signals
	STATE_SYNC_PROC:process(clk)
	begin
		if rising_edge(clk) then
		
			--Synchronize State Machine
			state 				<= next_state;
			
			--Delay this signals to account for Main Memory Latency when Reading
			IR_reg_we 			<= IR_reg_we_async;
			N_reg_we 			<= N_reg_we_async;
			Op1_reg_we			<= Op1_reg_we_async;
			Op2_reg_we			<= Op2_reg_we_async;
			--ALU Ctrl must wait two cycles to fetch data from CCR
			ALU_reg_we_pipe		<= ALU_reg_we_async;
			ALU_reg_we			<= ALU_reg_we_pipe;
			
			if reset = '1' then
				state 			<= st_reset;
			end if;
		end if;
	end process;
	
	---------------------------------------------
	--Operand data mux, use A0 to select between Mem Hi/Lo and between CCR/Ext Inputs, use highest possible Mem address to select between both muxes (in total it should be one 4:1 mux)
	Mem_hi_lo_mux		<= 	from_main_mem.dout_hi 	when addr_gen_out_A0_delay = '1' else
							from_main_mem.dout_lo;
		
	CCR_EXT_Mux_data	<=	external_input 			when addr_gen_out_A0_delay = '1' else
							resize_unsigned_slv(CCR_dout,CCR_EXT_Mux_data'length);
							
	-- Operand_mux_data 	<= 	CCR_EXT_Mux_data 		when signed(addr_gen_to_main_mem) = -1 else --All ones condition
							-- Mem_hi_lo_mux;

	Operand_mux_data 	<= 	CCR_EXT_Mux_data 		when addr_gen_out_A15_delay = '1' else --Use A15
							Mem_hi_lo_mux;							
							
	---------------------------------------------
	
	--Transform Instruction data from SLV to record type
	IR_Reg_async 						<= hay4stk_instruction_slv_to_rtype(from_main_mem.dout_hi);
	
	--Send Addrgen data
	addr_gen_ctrl_out.SPn_Sel 			<= IR_reg.LL_bits;  		--Send SPn bits to Addr Gen
	addr_gen_ctrl_out.M_bits 			<= IR_reg.M_bits;  			--Send M bits to Addr Gen
	addr_gen_ctrl_out.N_in 				<= N_reg;  					--Send N to Addr Gen
	addr_gen_ctrl_out.Main_MEM_hi16 	<= from_main_mem.dout_hi;  			--
	addr_gen_ctrl_out.Main_MEM_lo16 	<= from_main_mem.dout_lo;  			--
	addr_gen_ctrl_out.Op2_in			<= Op2_reg;
	
	REGS_PROC:process(clk)
	begin
		if rising_edge(clk) then
		
			if N_reg_we = '1' then
				N_reg			<= N_bits;
			end if;
			
			if IR_reg_we = '1' then
				IR_reg			<= IR_Reg_async;
			end if;
			
			if ALU_reg_we = '1' then
				--Decode instruction Data into ALU Controls, CCR is needed for Carry information
				ALU_ctrl_reg	<= hay4stk_alu_decode(IR_reg,CCR_dout_rtype);
			end if;
			
			if Op1_reg_we = '1' then
				Op1_reg			<= Operand_mux_data;
			end if;
			
			if Op2_reg_we = '1' then
				Op2_reg			<= Operand_mux_data;
			end if;

			if IR_reg_we_async = '1' then
				--Both have to be 0, to latch N into Op2
				addr_gen_out_A0_delay			<= '0';
				addr_gen_out_A15_delay			<= '0';
			else
				--Remember the A0 of the previous cycle (because of memory latency)
				addr_gen_out_A0_delay			<= addr_gen_data_in(addr_gen_data_in'low);
				--Remember A15 of the previous cycle (because of memory latency)
				addr_gen_out_A15_delay			<= addr_gen_data_in(addr_gen_data_in'high);
			end if;
			
			
			
			if reset = '1' then
				--!!!!IMPORTANT INIT INSTRUCTION is Branch to Address 0, and Op2 Reg contains the initial code vector
				Op2_reg 			<= HAY4STK_PC_START_ADDR;
				IR_reg.OpCode  		<= HAY4STK_INSTR_OPCODE_BR_NOP;
				IR_reg.R_bits	  	<= "1";
				IR_reg.T_bits	  	<= "1";
				IR_reg.M_bits	  	<= "110";
				N_reg  				<= (others => '0');
			end if;
		end if;
	end process;
	
	Op1_reg_out 		<= Op1_reg;
	Op2_reg_out 		<= Op2_reg;
	N_reg_out 			<= N_reg;
	
	ALU_ctrl_out 		<= ALU_ctrl_reg;
	
	
	addr_gen_to_main_mem			<=  addr_gen_data_in(addr_gen_to_main_mem'range) when AddrGen_RdAddrTemp = HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC else 					--PC addresses directly since it is 32-bits
										addr_gen_data_in(to_main_mem.addr'length+addr_gen_data_in'low+1-1 downto addr_gen_data_in'low+1); 	--Data is address as 16-bit (divide by two)
--	addr_bus_out					<=  addr_gen_data_in(addr_bus_out'range) when AddrGen_RdAddrTemp = HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC else 					--PC addresses directly since it is 32-bits
--										'0'&addr_gen_data_in(addr_gen_data_in'high downto addr_gen_data_in'low+1); 							--Data is address as 16-bit (divide by two)
--	addr_bus_out					<=  '0'&addr_gen_data_in(addr_gen_data_in'high downto addr_gen_data_in'low+1); 							--Data is address as 16-bit (divide by two)
	addr_gen_ctrl_out.RdAddr_sel 	<= AddrGen_RdAddrTemp;
	--
	to_main_mem.addr				<= addr_gen_to_main_mem;
	to_main_mem.din					<= alu_did_mux_in&alu_did_mux_in; --WE of BRAM will determine where it gets written
	
	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	--CCR & Branch Control Stuff
	
	--For now do not use
	CCR_addr_sel <= (others => '0');
	
	--Decode and convert to SLV
	CCR_logic 	<=  hay4stk_ccr_rtype_to_slv( hay4stk_alu_ccr_decode(alu_did_mux_in,alu_Cout,alu_Overflow) );
	CCR_din 	<= 	alu_did_mux_in(CCR_din'range) when CCR_addr_sel = "1" else
					CCR_logic;
					
	CCR_we		<= CCR_we_async;
	
	CCR_RAM_PROC:process(clk)
	begin
		if rising_edge(clk) then
		
			if CCR_we = '1' then
				CCR_RAM( to_integer(unsigned(IR_reg.LL_bits)) ) <= CCR_din;
			end if;
			
		end if;
	end process;
	
	--CCR RAM Output
	CCR_dout 		<= CCR_RAM( to_integer(unsigned(IR_reg.LL_bits)) );
	--Convert to Record Type
	CCR_dout_rtype 	<= hay4stk_ccr_slv_to_rtype(CCR_dout);
		
	--Determine if Branch is taken or not
	Branch_Ctrl 	<= hay4stk_ccr_branch_decode(IR_reg,CCR_dout_rtype); --'1': Branch Taken
	---------------------------------------------
	---------------------------------------------
	---------------------------------------------
	
	--Simulation only constructs
	--synthesis translate_off
	
	is_ALU_inst 	<= '1' when hay4stk_instr_is_alu(IR_Reg) else '0';
	is_BRANCH_inst 	<= '1' when hay4stk_instr_is_branch(IR_Reg) else '0';
	is_IMM_inst 	<= '1' when hay4stk_instr_is_imm(IR_Reg) else '0';
	
	--synthesis translate_on
	
end RTL;