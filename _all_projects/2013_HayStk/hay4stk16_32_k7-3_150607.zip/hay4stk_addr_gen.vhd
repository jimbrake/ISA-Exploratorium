----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- 
-- Create Date:		             
-- Design Name:		                                        
-- Module Name:		    hay4stk_addr_gen.vhd
-- Project Name:		hay4stk16_32
-- Target Devices: 
-- Tool versions: 
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;

entity hay4stk_addr_gen is
port
(
	reset			 		 	: in std_logic; --Sync Reset
	clk				 		 	: in std_logic; --Clk input
	
	addr_gen_ctrl_in			: in hay4stk_addrgen_ctrl_rtype; 	--Inputs

	EAR_Reg_out					: out hay4stk_Addrgen_RAM_data_type;   --Effective Address Register Output
	Addr_out				 	: out hay4stk_Addrgen_RAM_data_type	--Address Output
);
end hay4stk_addr_gen;
    
architecture RTL of hay4stk_addr_gen is

	signal Addrgen_RAM		 	: hay4stk_Addrgen_RAM_type;
	signal Addrgen_RAM_rd_addr	: hay4stk_Addrgen_RAM_addr_type;
	signal Addrgen_RAM_wr_addr	: hay4stk_Addrgen_RAM_addr_type;
	signal Addrgen_RAM_din		: hay4stk_Addrgen_RAM_data_type;
	signal Addrgen_RAM_dout	 	: hay4stk_Addrgen_RAM_data_type;
	signal EAR_Reg			 	: hay4stk_Addrgen_RAM_data_type;
	signal EAR_result		 	: hay4stk_Addrgen_RAM_data_type;
	signal addr_sel_mux		 	: hay4stk_Addrgen_RAM_data_type;
	signal delta_result		 	: hay4stk_Addrgen_RAM_data_type;
	signal addr_alu_result	 	: hay4stk_Addrgen_RAM_data_type;

begin
	---------------------------------------------
	EAR_REG_PROC:process(clk)
	begin
		if rising_edge(clk) then
			--Reset state might not be necessary for this reg (save routing and wires)
			if addr_gen_ctrl_in.EAR_we(0) = '1' then
				EAR_Reg <= Addrgen_RAM_dout;
			end if;
		end if;
	end process;
	
	EAR_Reg_out	 <= EAR_Reg;
	
	EAR_result   <= EAR_Reg 				when addr_gen_ctrl_in.EAR_sel = HAY4STK_ADDRGEN_CTRL_EAR_MUX_EAR else
					Addrgen_RAM_dout;
	---
	with  addr_gen_ctrl_in.addr_sel  select addr_sel_mux <= EAR_result 							when HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX,
	    													addr_gen_ctrl_in.Op2_in 			when HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_OP2,
															addr_gen_ctrl_in.Op2_in 			when others;
	---
	---
	with  addr_gen_ctrl_in.Delta_sel select delta_result <=
																std_logic_vector(to_signed(0,delta_result'length))  when HAY4STK_ADDRGEN_CTRL_DELTA_MUX_0,
																std_logic_vector(to_signed(1,delta_result'length))  when HAY4STK_ADDRGEN_CTRL_DELTA_MUX_1,
																std_logic_vector(to_signed(-1,delta_result'length)) when HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N1,
																addr_gen_ctrl_in.N_in 								when HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N,
																addr_gen_ctrl_in.N_in 								when others;
	---------------------------------------------								
	---Address ALU
	addr_alu_result <= std_logic_vector( signed(delta_result)+signed(addr_sel_mux) );
	---------------------------------------------
	--RAM with Async Read inference (hopefully gets inferred)
	Addrgen_RAM_PROC:process(clk)
	begin
		if rising_edge(clk) then
			if addr_gen_ctrl_in.Addrgen_RAM_wr_en = "1" then
				--RAM Sync Write
				 Addrgen_RAM( to_integer(unsigned(Addrgen_RAM_wr_addr)) ) <= Addrgen_RAM_din;
			end if;
		end if;
		-- --This location always read as zero
		-- Addrgen_RAM(to_integer(unsigned(HAY4STK_Addrgen_RAM_0_ADDR))) <= (others => '0');
	end process;
	
	Addrgen_RAM_din <= addr_alu_result;
	
	--RAM Async Read
	Addrgen_RAM_dout <= Addrgen_RAM( to_integer(unsigned(Addrgen_RAM_rd_addr)) );
	---------------------------------------------
	--AddrRAM: Wr Addr Mux
	with  addr_gen_ctrl_in.WrAddr_sel select Addrgen_RAM_wr_addr <=
																'0'&addr_gen_ctrl_in.SPn_sel	when HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN,
																'1'&addr_gen_ctrl_in.SPn_sel	when HAY4STK_ADDRGEN_CTRL_ADDRSEL_1_SPN,
																addr_gen_ctrl_in.M_bits			when HAY4STK_ADDRGEN_CTRL_ADDRSEL_M_BITS,
																hay4stk_Addrgen_RAM_pc_addr		when HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC,
																hay4stk_Addrgen_RAM_pc_addr		when others;
	--AddrRAM: Rd Addr Mux
	with  addr_gen_ctrl_in.RdAddr_sel select Addrgen_RAM_rd_addr <=
																'0'&addr_gen_ctrl_in.SPn_sel	when HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN,
																'1'&addr_gen_ctrl_in.SPn_sel	when HAY4STK_ADDRGEN_CTRL_ADDRSEL_1_SPN,
																addr_gen_ctrl_in.M_bits			when HAY4STK_ADDRGEN_CTRL_ADDRSEL_M_BITS,
																hay4stk_Addrgen_RAM_pc_addr		when HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC,
																hay4stk_Addrgen_RAM_pc_addr		when others;
	---------------------------------------------																	
	--Output Address Mux
	with  addr_gen_ctrl_in.Addrgen_mux_sel select Addr_out	  <=
																EAR_result						when HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR,
																addr_alu_result					when HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_ADDR_ALU,
																addr_gen_ctrl_in.Main_MEM_hi16	when HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_MAIN_MEM_HI,
																addr_gen_ctrl_in.Main_MEM_lo16	when HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_MAIN_MEM_LO,
																addr_gen_ctrl_in.Main_MEM_lo16	when others;
	--
	
	--Simulation only constructs
	--synthesis translate_off
	VERIFICATION_PROC:process
	begin
		while true loop
			wait on clk until rising_edge(clk) AND reset = '0';
			if addr_gen_ctrl_in.Addrgen_RAM_wr_en = "1" AND Addrgen_RAM_wr_addr = "111" then
				assert FALSE report "***ERROR: Location '111' of  AddrRAM should not be written!!!" severity FAILURE;
			end if;
		end loop;
		wait;
	end process;
	--synthesis translate_on
	
end RTL;