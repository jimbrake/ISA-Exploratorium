----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--


LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_defs_pkg.ALL;
--USE hay4stk.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;

package hay4stk_assembler_pkg is

--  convenience constants for forming valid instructions

--      first the option bit patterns
constant op_R:		hay4stk_main_mem_data_type	:=	"00000100000000000000000000000000";		-- replace memory operand
constant op_SP0:	hay4stk_main_mem_data_type	:=	"00000000000000000000000000000000";		-- stack selection (SP0 thru SP3)
constant op_SP1:	hay4stk_main_mem_data_type	:=	"00000001000000000000000000000000";
constant op_SP2:	hay4stk_main_mem_data_type	:=	"00000010000000000000000000000000";
constant op_SP3:	hay4stk_main_mem_data_type	:=	"00000011000000000000000000000000";
--      Size bits, not in use at this time
constant op_SZ8:	hay4stk_main_mem_data_type	:=	"00000000000000000000000000000000";		-- 8-bit memory data & operation
constant op_SZ16:	hay4stk_main_mem_data_type	:=	"00000000010000000000000000000000";		-- 16-bit memory data & operation
constant op_SZ32:	hay4stk_main_mem_data_type	:=	"00000000100000000000000000000000";		-- 32-bit memory data & operation
constant op_SZ64:	hay4stk_main_mem_data_type	:=	"00000000110000000000000000000000";		-- 64-bit memory data & operation

constant op_P:		hay4stk_main_mem_data_type	:=	"00000000001000000000000000000000";		-- P bit, if set use stack mode, e.g. push or pop stack
constant op_T:		hay4stk_main_mem_data_type	:=	"00000000000100000000000000000000";		-- T bit, if set advance M register by displacement
--      Return bit, not in use at this time
constant op_rt:		hay4stk_main_mem_data_type	:=	"00000000000010000000000000000000";		-- return bit, if set pop PC from M(SP0++)
constant op_MSP0:	hay4stk_main_mem_data_type	:=	"00000000000000000000000000000000";		-- M bits, specify pointer register for offset addressing
constant op_MSP1:	hay4stk_main_mem_data_type	:=	"00000000000000010000000000000000";		
constant op_MSP2:	hay4stk_main_mem_data_type	:=	"00000000000000100000000000000000";		
constant op_MSP3:	hay4stk_main_mem_data_type	:=	"00000000000000110000000000000000";		
constant op_FP:		hay4stk_main_mem_data_type	:=	"00000000000001000000000000000000";		-- frame pointer
constant op_TP:		hay4stk_main_mem_data_type	:=	"00000000000001010000000000000000";		-- thread pointer
constant op_PCR:	hay4stk_main_mem_data_type	:=	"00000000000001100000000000000000";		-- instruction pointer
constant op_ABS:	hay4stk_main_mem_data_type	:=	"00000000000001110000000000000000";		-- absolute addressing

--      the basic instructions
constant z27:		std_logic_vector(26 downto 0):=	     "000000000000000000000000000";		-- 27 bits of zero
constant op_CALL:    hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_CALL & z27) OR op_R;
constant op_RTN:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_RTN & z27) OR op_T OR op_PCR;
constant op_JMP_RTN: hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_JMP_RTN & z27);
-- constant op_LSP0wEA: hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_LD_PTR & z27);
-- constant op_LSP1wEA: hay4stk_main_mem_data_type := op_LSP0wEA OR op_SP1;
-- constant op_LSP2wEA: hay4stk_main_mem_data_type := op_LSP0wEA OR op_SP2;
-- constant op_LSP3wEA: hay4stk_main_mem_data_type := op_LSP0wEA OR op_SP3;
--
constant op_LSP0wEA: hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_LD_PTR & z27) OR op_MSP0;
constant op_LSP1wEA: hay4stk_main_mem_data_type := op_LSP0wEA OR op_MSP1;
constant op_LSP2wEA: hay4stk_main_mem_data_type := op_LSP0wEA OR op_MSP2;
constant op_LSP3wEA: hay4stk_main_mem_data_type := op_LSP0wEA OR op_MSP3;
--
-- constant op_LFPwEA:  hay4stk_main_mem_data_type := op_LSP0wEA OR op_SP0 OR op_P;
-- constant op_LTPwEA:  hay4stk_main_mem_data_type := op_LSP0wEA OR op_SP1 OR op_P;
-- constant op_LPCwEA:  hay4stk_main_mem_data_type := op_LSP0wEA OR op_SP2 OR op_P;
constant op_LFPwEA:  hay4stk_main_mem_data_type := op_LSP0wEA OR op_FP;
constant op_LTPwEA:  hay4stk_main_mem_data_type := op_LSP0wEA OR op_TP;
constant op_LPCwEA:  hay4stk_main_mem_data_type := op_LSP0wEA OR op_PCR;

constant op_LD:      hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_LD & z27);
constant op_LDI:     hay4stk_main_mem_data_type := op_LD OR op_PCR OR op_T;
constant op_ST:      hay4stk_main_mem_data_type := op_LD OR op_R;
constant op_CMP:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_CMP & z27);
constant op_CMPI:    hay4stk_main_mem_data_type := op_CMP OR op_PCR OR op_T;
constant op_BIT:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BIT & z27);
constant op_BITI:    hay4stk_main_mem_data_type := op_BIT OR op_PCR OR op_T;
constant op_INC:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_INC & z27) OR op_R;
constant op_DEC:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_INC & z27) OR op_R OR op_SP1;
constant op_CLR:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_INC & z27) OR op_R OR op_SP2;
constant op_SET:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_INC & z27) OR op_R OR op_SP3;
constant op_AND:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_AND & z27);
constant op_ANDI:    hay4stk_main_mem_data_type := op_AND OR op_PCR OR op_T;
constant op_RAND:    hay4stk_main_mem_data_type := op_AND OR op_R;
constant op_OR:      hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_OR & z27);
constant op_ORI:     hay4stk_main_mem_data_type := op_OR OR op_PCR OR op_T;
constant op_ROR:     hay4stk_main_mem_data_type := op_OR OR op_R;
constant op_XOR:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_XOR & z27);
constant op_XORI:    hay4stk_main_mem_data_type := op_XOR OR op_PCR OR op_T;
constant op_RXOR:    hay4stk_main_mem_data_type := op_XOR OR op_R;
constant op_ANDN:    hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_ANDN & z27);
constant op_ANDNI:   hay4stk_main_mem_data_type := op_ANDN OR op_PCR OR op_T;
constant op_RANDN:   hay4stk_main_mem_data_type := op_ANDN OR op_R;
constant op_ADD:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_ADD & z27);
constant op_ADDI:    hay4stk_main_mem_data_type := op_ADD OR op_PCR OR op_T;
constant op_RADD:    hay4stk_main_mem_data_type := op_ADD OR op_R;
constant op_ADC:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_ADC & z27);
constant op_ADCI:    hay4stk_main_mem_data_type := op_ADC OR op_PCR OR op_T;
constant op_RADC:    hay4stk_main_mem_data_type := op_ADC OR op_R;
constant op_SUB:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_SUB & z27);
constant op_SUBI:    hay4stk_main_mem_data_type := op_SUB OR op_PCR OR op_T;
constant op_RSUB:    hay4stk_main_mem_data_type := op_SUB OR op_R;
constant op_SBC:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_SBC & z27);
constant op_SBCI:    hay4stk_main_mem_data_type := op_SBC OR op_PCR OR op_T;
constant op_RSBC:    hay4stk_main_mem_data_type := op_SBC OR op_R;
constant op_MUL:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_MUL & z27);
constant op_MULI:    hay4stk_main_mem_data_type := op_MUL OR op_PCR OR op_T;
constant op_RMUL:    hay4stk_main_mem_data_type := op_MUL OR op_R;
constant op_MULUU:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_MULUU & z27);
constant op_MULUUI:  hay4stk_main_mem_data_type := op_MULUU OR op_PCR OR op_T;
constant op_RMULUU:  hay4stk_main_mem_data_type := op_MULUU OR op_R;
constant op_MULSU:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_MULSU & z27);
constant op_MULSUI:  hay4stk_main_mem_data_type := op_MULSU OR op_PCR OR op_T;
constant op_RMULSU:  hay4stk_main_mem_data_type := op_MULSU OR op_R;

--      the branch instructions
constant op_BR:     hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BR_NOP & z27) 		OR op_PCR OR op_T OR op_R; 
constant op_NOP:    hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BR_NOP & z27) 		OR op_ABS OR op_T OR op_R; 
constant op_BROD:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BROD_BREV & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BREV:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BROD_BREV & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BRZ:    hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRZ_BRNZ & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BRNZ:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRZ_BRNZ & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BREQ:   hay4stk_main_mem_data_type  := op_BRZ;
constant op_BRNEQ:   hay4stk_main_mem_data_type := op_BRNZ;
constant op_BRNE:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRZ_BRNZ & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BRCS:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRCS_BRCC & z27)	OR op_PCR OR op_T OR op_R; 
constant op_BRCC:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRCS_BRCC & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BRHS:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRCS_BRCC & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BRLO:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRCS_BRCC & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BROV:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BROV_BRNOV & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BRNOV:  hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BROV_BRNOV & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BRGE:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRGE_BRLT & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BRLT:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRGE_BRLT & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BRM:    hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRM_BRP & z27) 		OR op_PCR OR op_T OR op_R; 
constant op_BRP:    hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRM_BRP & z27) 		OR op_ABS OR op_T OR op_R; 
constant op_BRGT:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRGT_BRLE & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BRLE:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRGT_BRLE & z27) 	OR op_ABS OR op_T OR op_R; 
constant op_BRHI:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRHI_BRLS & z27) 	OR op_PCR OR op_T OR op_R; 
constant op_BRLS:   hay4stk_main_mem_data_type := (HAY4STK_INSTR_OPCODE_BRHI_BRLS & z27) 	OR op_ABS OR op_T OR op_R; 

end hay4stk_assembler_pkg;