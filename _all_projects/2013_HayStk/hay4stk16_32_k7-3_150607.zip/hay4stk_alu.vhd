----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- 
-- Create Date:		             
-- Design Name:		                                        
-- Module Name:		    hay4stk_alu.vhd
-- Project Name:		hay4stk16_32
-- Target Devices: 
-- Tool versions: 
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;

entity hay4stk_alu is
port
(
	reset			: in std_logic; --Sync Reset
	clk				: in std_logic; --Clk input
	
	alu_ctrl_in		: in hay4stk_alu_ctrl_rtype; 	--Inputs
	Op1_Reg			: in hay4stk_operand_data_type; 	--
	Op2_Reg			: in hay4stk_operand_data_type;
	EAR_Reg			: in hay4stk_Addrgen_RAM_data_type;
	
	DID_out			: out std_logic_vector(16-1 downto 0); 	--
	ALU_out			: out hay4stk_operand_data_type; 	--
	Overflow_out	: out std_logic;
	Cout			: out std_logic
);
end hay4stk_alu;
    
architecture RTL of hay4stk_alu is

	signal ALU_Result_temp 		: std_logic_vector(17-1 downto 0);
	signal ALU_Result 			: hay4stk_operand_data_type;
	signal Bool_Result_temp		: hay4stk_operand_data_type;
	signal Bool_Result 			: hay4stk_operand_data_type;
	signal Op2_EAR_mux 			: hay4stk_operand_data_type;
	signal Cin_temp				: hay4stk_operand_data_type;
	signal Op2_Ctrl_mux			: hay4stk_operand_data_type;
	signal DID_mux				: std_logic_vector(DID_out'range);
	
	alias ALU_Result_temp_sign_bit 	: std_logic is ALU_Result_temp(ALU_Result_temp'high-1);
	alias Bool_Result_sign_bit 		: std_logic is Bool_Result(Bool_Result'high);
	alias Op2_sign_bit 				: std_logic is Op2_Ctrl_mux(Op2_Ctrl_mux'high);
	
	signal alu_ctrl_in_reg		: hay4stk_alu_ctrl_rtype;
	
	signal Mult_Op1				: std_logic_vector(17-1 downto 0);
	signal Op1_Reg_d			: hay4stk_operand_data_type;
	signal Mult_Op2				: std_logic_vector(17-1 downto 0);
	signal Mult_out_temp		: std_logic_vector(Mult_Op1'length+Mult_Op2'length-1 downto 0);
	signal Mult_out_temp_reg	: std_logic_vector(Mult_out_temp'range);
	signal Op2_Reg_d			: hay4stk_operand_data_type;
	signal Cin_reg				: std_logic;	-- registered Cin
	signal Cout_temp			: std_logic;	-- used to register Cout
	
	attribute USE_DSP48 : string;
	attribute USE_DSP48 of Mult_out_temp	: signal is "YES";
	attribute USE_DSP48 of ALU_Result_temp	: signal is "NO";

begin

	
	---------------------------------------------
	--Put the carry input in this vector
	Cin_temp 		<= (0 => Cin_reg, others => '0'); 
	--Do the addition
	ALU_Result_temp <= std_logic_vector(unsigned('0'&Bool_Result) + unsigned('0'&Op2_Ctrl_mux) + unsigned('0'&Cin_temp));
	--Assign ALU output
	ALU_Result 		<= ALU_Result_temp(ALU_Result'range);
	--Overflow Out
	--If sign bits of both operands are the same and the result is a different sign then there is overflow
	Overflow_out	<= NOT(
							(Bool_Result_sign_bit XOR Op2_sign_bit) 		--Both operands signs are the same yields '0'
							OR
							NOT(ALU_Result_temp_sign_bit XOR Op2_sign_bit) 	--Result sign is the same as operand sign yields '1'
						  );
	--Assign Carry Out
	Cout_temp		<= ALU_Result_temp(ALU_Result_temp'high);
	---------------------------------------------
	--Boolean Operations
	BOOL_RESULT_PROC:process(alu_ctrl_in_reg.Bool_Ctrl,Op2_EAR_mux,Op1_Reg)
	begin
	
		Bool_Result_temp <= (others => '0'); --Default assignment so we don't get a latch in case we screw up
	
		case alu_ctrl_in_reg.Bool_Ctrl is
			when HAY4STK_ALU_BOOLCTRL_1AND2 	=>	Bool_Result_temp <= Op1_Reg AND Op2_EAR_mux;
			when HAY4STK_ALU_BOOLCTRL_1AND2N	=>	Bool_Result_temp <= Op1_Reg AND NOT(Op2_EAR_mux);
			when HAY4STK_ALU_BOOLCTRL_N1AND2	=>	Bool_Result_temp <= NOT(Op1_Reg) AND Op2_EAR_mux;
			when HAY4STK_ALU_BOOLCTRL_1OR2 		=>	Bool_Result_temp <= Op1_Reg OR Op2_EAR_mux;
			when HAY4STK_ALU_BOOLCTRL_1XOR2 	=>	Bool_Result_temp <= Op1_Reg XOR Op2_EAR_mux;
			when HAY4STK_ALU_BOOLCTRL_OP1		=>	Bool_Result_temp <= Op1_Reg;
			when HAY4STK_ALU_BOOLCTRL_OP2 		=>	Bool_Result_temp <= Op2_EAR_mux;
			when HAY4STK_ALU_BOOLCTRL_0 		=>	Bool_Result_temp <= (others => '0');
			when others				 			=>	Bool_Result_temp <= (others => '0');
		end case;
		
	end process;
	
	Bool_Result <= 	Bool_Result_temp 		when alu_ctrl_in_reg.nBool_Ctrl = "0" else
							NOT(Bool_Result_temp);
	---------------------------------------------
	--Op2 Sel Mux
	with  alu_ctrl_in_reg.Op2_EAR_mux_sel select Op2_EAR_mux <=
																EAR_Reg	when HAY4STK_ALU_OP2EARMUX_EAR,
																Op2_Reg	when HAY4STK_ALU_OP2EARMUX_OP2,
																Op2_Reg	when others;
	--Op2 Ctrl Mux
	with  alu_ctrl_in_reg.Op2_Ctrl_mux_sel select Op2_Ctrl_mux <=
																to_signed_slv(0,Op2_Ctrl_mux'length)		when HAY4STK_ALU_OP2CTRLMUX_0,
																Op2_EAR_mux									when HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX,
																NOT(Op2_EAR_mux)							when HAY4STK_ALU_OP2CTRLMUX_NOP2SELMUX,
																to_signed_slv(1,Op2_Ctrl_mux'length)		when HAY4STK_ALU_OP2CTRLMUX_1,																	
																to_signed_slv(1,Op2_Ctrl_mux'length)		when others;																	
	--DID SEl Mux
	with  alu_ctrl_in_reg.DID_sel select DID_mux  <=
													resize_unsigned_slv(ALU_Result,DID_mux'length)			when HAY4STK_ALU_DIDMUX_ALU,
													to_signed_slv(0,DID_mux'length)							when HAY4STK_ALU_DIDMUX_SPARE,
													Mult_out_temp_reg(15 downto 0)							when HAY4STK_ALU_DIDMUX_MULTLO,
													Mult_out_temp_reg(31 downto 16)							when HAY4STK_ALU_DIDMUX_MULTHI,
													Mult_out_temp_reg(31 downto 16)							when others;

	---------------------------------------------
	--Multiplication Operands
	Mult_Op1 <= 					'0'&Op1_Reg_d when alu_ctrl_in_reg.Mult_Sgn_extend = "0" 	--UNsigned multiplication
							else 	resize_signed_slv(Op1_Reg_d,Mult_Op1'length); 		--SIgned multiplication (Sign Extend)
							
	Mult_Op2 <= 					'0'&Op2_Reg_d when alu_ctrl_in_reg.Mult_Sgn_extend = "0" 	--UNsigned multiplication
							else 	resize_signed_slv(Op2_Reg_d,Mult_Op2'length); 		--SIgned multiplication (Sign Extend)
	--Finally multiply 17 by 17 signed
	Mult_out_temp 	<= std_logic_vector( signed(Mult_Op1)*signed(Mult_Op2) );
	-- ---------------------------------------------
	-- --Temporarily register operands and output
	-- --A hack to get a useful Fmax
	-- process(clk)
	-- begin
		-- if rising_edge(clk) then
			-- Cin_reg		<= Cin;
			-- Cout		<= Cout_temp;
			-- Op1_Reg_d	<= Op1_Reg;
			-- Op2_Reg_d	<= Op2_Reg;
			-- ALU_out 			<= ALU_Result;
			-- alu_ctrl_in_reg 			<= alu_ctrl_in;
			-- Mult_out_temp_reg <= Mult_out_temp;
			-- DID_out <= DID_mux;
		-- end if;
	-- end process;
	
			--Combinational
			Cin_reg				<= alu_ctrl_in.Cin;
			Cout				<= Cout_temp;
			Op1_Reg_d			<= Op1_Reg;
			Op2_Reg_d			<= Op2_Reg;
			ALU_out 			<= ALU_Result;
			alu_ctrl_in_reg 	<= alu_ctrl_in;
			Mult_out_temp_reg 	<= Mult_out_temp;
			DID_out 			<= DID_mux;
	---------------------------------------------
end RTL;