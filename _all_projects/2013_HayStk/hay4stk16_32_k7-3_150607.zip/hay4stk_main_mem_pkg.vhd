----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--


LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

library std;
use std.textio.all;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_defs_pkg.ALL;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_assembler_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_assembler_pkg.ALL;

package hay4stk_main_mem_pkg is

	function 		hay4stk_InitMainMem 		(code_start_pos : hay4stk_main_mem_addr_type := (others => '0')) return hay4stk_main_mem_type;
	impure function hay4stk_InitMainMemFromFile (RamFileName : in string) return hay4stk_main_mem_type;	

end hay4stk_main_mem_pkg;

package body hay4stk_main_mem_pkg is


	
	function hay4stk_InitMainMem (code_start_pos : hay4stk_main_mem_addr_type := (others => '0')) return hay4stk_main_mem_type is
	variable code			: hay4stk_main_mem_type;
	variable code_pos		: integer;
	begin
		
		--Default value for all instructions
		code 			:= 
						(others => op_BR 						OR X"00000000"); --Loop unconditionally in the same place
	
		--Load the starting position for the code (default 0)
		code_pos		:= to_integer(unsigned(code_start_pos));
		
		--Replace default value with desired instruction
		code(code_pos)	:= op_LSP0wEA 				OR op_P	OR X"00000100";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LSP1wEA 				OR op_P	OR X"00000200";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LSP2wEA 				OR op_P	OR X"00000300";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LSP3wEA 				OR op_P	OR X"00000380";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LDI  		OR op_SP0 	OR op_P OR X"00000101";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LDI  		OR op_SP1 	OR op_P OR X"00000102";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LDI  		OR op_SP2 	OR op_P OR X"00000103";code_pos	:= code_pos+1;
		code(code_pos)	:= op_ADDI 		OR op_SP3 	OR op_P OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_ADDI 		OR op_SP3 	OR op_P OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_CMPI 		OR op_SP3 			OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_BREQ 		OR op_SP3 			OR X"00000010";code_pos	:= code_pos+1;
		code(code_pos)	:= op_CMPI 		OR op_SP3 			OR X"00000105";code_pos	:= code_pos+1;
		code(code_pos)	:= op_BREQ 		OR op_SP3 			OR X"00000003";code_pos	:= code_pos+1;
		code(code_pos)	:= op_BRHI 		OR op_SP3 			OR X"00000008";code_pos	:= code_pos+1;
		code(code_pos)	:= op_BREQ 		OR op_SP3 			OR X"00000008";code_pos	:= code_pos+1;
		code(code_pos)	:= op_CMP  		OR op_SP2 			OR X"00000000";code_pos	:= code_pos+1;
		code(code_pos)	:= op_CALL		OR op_SP0 	OR op_P OR X"00000030";code_pos	:= code_pos+1;
		code(code_pos)	:= op_ADDI 		OR op_SP2 	OR op_P OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_ADDI 		OR op_SP2 	OR op_P OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_LPCwEA 	                    OR X"00000001";code_pos	:= code_pos+1;
		
		
		--Function at offset
		code_pos := 64;
		code(code_pos)	:= op_ADDI 		OR op_SP1 	OR op_P OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_ADDI 		OR op_SP1 			OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_ADDI 		OR op_SP1 			OR X"00000001";code_pos	:= code_pos+1;
		code(code_pos)	:= op_RTN 		OR op_SP0 			OR X"00000001";code_pos	:= code_pos+1;
		
		return code;
	end function hay4stk_InitMainMem;
	
	impure function hay4stk_InitMainMemFromFile (RamFileName : in string) return hay4stk_main_mem_type is
	file RamFile			: text open READ_MODE is RamFileName;
	variable printWarning 	: integer;
	variable RamFileLine 	: line;
	variable RAM 			: hay4stk_main_mem_type;
	variable temp_bv		: bit_vector(32-1 downto 0);
	begin
		printWarning := 0;
		assert is_power_of_2(hay4stk_main_mem_type'length) report "RAM size is not power of 2, remaining positions will not be filled (unknown)..." severity WARNING;
		for i in RAM'low to RAM'high loop
			if endfile(RamFile) then
				--End of file reached before reaching end of RAM
				printWarning := printWarning+1;
				RAM(i) := to_stdlogicvector(temp_bv);
			else
				--continue reading
				readline (RamFile, RamFileLine);
				read (RamFileLine, temp_bv);
				RAM(i) := to_stdlogicvector(temp_bv);
			end if;
		end loop;
		assert printWarning=0 report "End of file reached before reaching end of RAM, filling rest ("&integer'image(printWarning)&") of RAM with last valid value..." severity WARNING;
		return RAM;
	end function hay4stk_InitMainMemFromFile;

end hay4stk_main_mem_pkg;