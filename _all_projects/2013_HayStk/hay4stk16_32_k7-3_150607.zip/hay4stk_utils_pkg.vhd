----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--

library IEEE;
use IEEE.std_logic_1164.all;
USE IEEE.NUMERIC_STD.ALL;
use IEEE.MATH_REAL.all;

package hay4stk_utils_pkg is

	function to_unsigned_slv  (input,input_length : in integer) return std_logic_vector; 	--!Capossio
	function to_signed_slv  (input,input_length : in integer) return std_logic_vector; 	--!Capossio
	
	function resize_signed_slv  (input:std_logic_vector;resize_length : in integer) return std_logic_vector; 	--!Capossio
	function resize_unsigned_slv  (input:std_logic_vector;resize_length : in integer) return std_logic_vector; 	--!Capossio
	
	---
	function or_reduce  	(input:std_logic_vector) return std_logic; --!Capossio
	function and_reduce  	(input:std_logic_vector) return std_logic; --!Capossio
	function xor_reduce 	(input:std_logic_vector) return std_logic; --!Capossio
	--
	
	function clog2  (constant a : in integer) return integer; 	--!Capossio
	function clog2  (constant a : in real) return integer; 	--!Capossio
	function clog2  (constant a : in real) return real; 	--!Capossio
	
	function is_power_of_2 (vec: std_logic_vector) return boolean;	--!Capossio
	function is_power_of_2 (num: integer) return boolean;		--!Capossio

end hay4stk_utils_pkg;

package body hay4stk_utils_pkg is

	--------
	--Ceiling of Logarithm Base 2 Variants
	function clog2 (constant a : in integer) return integer is
	begin
		return integer(ceil(log2(real(a)))); 
	end clog2;
	function clog2 (constant a : in real) return integer is
	begin
		return integer(ceil(log2(a))); 
	end clog2;
	function clog2 (constant a : in real) return real is
	begin
		return ceil(log2(a)); 
	end clog2;
	--------
	
	--------
	--OR all the bits in a Vector
	function or_reduce  (input:std_logic_vector) return std_logic is
	variable ret_bit : std_logic;
	begin
	
		assert input'length >= 2 report "Input vector must be at least 2 bits long" severity FAILURE;
	
		ret_bit := '0'; --'0' doesn't modify the result of the OR
		
		for i in input'range loop
			ret_bit := input(i) OR ret_bit;
		end loop;
		
		return ret_bit;

	end function or_reduce;
	--------
	--------
	--------
	--AND all the bits in a Vector
	function and_reduce  (input:std_logic_vector) return std_logic is
	variable ret_bit 	: std_logic;
	begin
	
		assert input'length >= 2 report "Input vector must be at least 2 bits long" severity FAILURE;
		
		ret_bit := '1'; --'1' doesn't modify the result of the AND
		
		for i in input'range loop
			ret_bit := input(i) AND ret_bit;
		end loop;
		
		return ret_bit;

	end function and_reduce;
	--------
	--XOR all the bits in a Vector
	function xor_reduce  (input:std_logic_vector) return std_logic is
	variable ret_bit 	: std_logic;
	begin
	
		assert input'length >= 2 report "Input vector must be at least 2 bits long" severity FAILURE;
	
		ret_bit := '0'; --'0' doesn't modify the result of the XOR
		
		for i in input'range loop
			ret_bit := input(i) XOR ret_bit;
		end loop;
		
		return ret_bit;

	end function xor_reduce;
	-- --------
	
	--------	
	function to_unsigned_slv  (input,input_length : in integer) return std_logic_vector is 	--!Capossio
	variable return_var : std_logic_vector(input_length-1 downto 0);
	begin
		
		return_var := std_logic_vector(to_unsigned(input,input_length));
		
		return return_var;
		
	end function to_unsigned_slv;
	--
	function to_signed_slv  (input,input_length : in integer) return std_logic_vector is 	--!Capossio
	variable return_var : std_logic_vector(input_length-1 downto 0);
	begin
		
		return_var := std_logic_vector(to_signed(input,input_length));
		
		return return_var;
		
	end function to_signed_slv;
	--------
	
	--------
	function resize_unsigned_slv  (input:std_logic_vector;resize_length : in integer) return std_logic_vector is 	--!Capossio
	variable return_var : std_logic_vector(resize_length-1 downto 0);
	begin
		
		return_var := std_logic_vector( resize(unsigned(input),resize_length) );
		
		return return_var;
		
	end function resize_unsigned_slv;
	--------
	--------
	function resize_signed_slv  (input:std_logic_vector;resize_length : in integer) return std_logic_vector is 	--!Capossio
	variable return_var : std_logic_vector(resize_length-1 downto 0);
	begin
		
		return_var := std_logic_vector( resize(signed(input),resize_length) );
		
		return return_var;
		
	end function resize_signed_slv;
	--------
	--------
	--------
	--!Capossio
	--!return TRUE if integer is power of 2
	function is_power_of_2 (vec: std_logic_vector) return boolean is
	variable ones_count 	: integer;
	begin

		ones_count := 0;
		for i in vec'range loop --Count all the ones
			if vec(i) = '1' then
				ones_count := ones_count + 1;
			end if;
		end loop;

		if ones_count = 1 then --If there is only one '1' then it is a power of two
			return  true;
		end if;

		return false;

	end function is_power_of_2;
	--------
	function is_power_of_2 (num: integer) return boolean is
	variable temp 			: std_logic_vector(clog2(integer'high)+1-1 downto 0); --Max integer
	begin

		temp := std_logic_vector(to_unsigned(abs(num),temp'length)); --Convert to slv
		return is_power_of_2(temp);

	end function is_power_of_2;
	--------
	--------
	--------
	
end hay4stk_utils_pkg;