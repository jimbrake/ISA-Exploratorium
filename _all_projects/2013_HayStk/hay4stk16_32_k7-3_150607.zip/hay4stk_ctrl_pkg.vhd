----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;

package hay4stk_ctrl_pkg is

	type hay4stk_control_machine_state_type is (st_reset,st_phase1,st_phase2,st_phase3,st_phase4,st_phase5,st_wait_Op2,
												st_unknown_opcode);
	function hay4stk_instr_main_mem_we 		(instruction : hay4stk_instruction_rtype) 		return std_logic;
	function hay4stk_instr_decode_state_ph1 (instruction : hay4stk_instruction_rtype) 		return hay4stk_control_machine_state_type;
	function hay4stk_instr_decode_state_ph2 (instruction : hay4stk_instruction_rtype) 		return hay4stk_control_machine_state_type;
	function hay4stk_alu_decode 			(instruction : hay4stk_instruction_rtype;CCR_Reg:hay4stk_ccr_rtype) 	return hay4stk_alu_ctrl_rtype;
	function hay4stk_instr_is_alu 			(instruction : hay4stk_instruction_rtype) 		return boolean;
	function hay4stk_instr_is_imm	 		(instruction : hay4stk_instruction_rtype) 		return boolean;
	function hay4stk_instr_is_branch 		(instruction : hay4stk_instruction_rtype) 		return boolean;
	function hay4stk_instr_is_ctrl	 		(instruction : hay4stk_instruction_rtype) 		return boolean;
	-- ---
	function hay4stk_alu_ccr_decode 		(alu_data_in:hay4stk_operand_data_type;alu_Cout	: std_logic;alu_Overflow	: std_logic) 	return hay4stk_ccr_rtype;
	function hay4stk_ccr_branch_decode 		(instruction:hay4stk_instruction_rtype;ccr_data_in : hay4stk_ccr_rtype	) return std_logic;
	function hay4stk_ccr_we_decode 			(instruction : hay4stk_instruction_rtype)			return std_logic;
	
end hay4stk_ctrl_pkg;

package body hay4stk_ctrl_pkg is

	--Decode State in phase1
	function hay4stk_instr_decode_state_ph1 	(instruction:hay4stk_instruction_rtype) 	return hay4stk_control_machine_state_type is
	variable output_state : hay4stk_control_machine_state_type;
	begin
	
		output_state := st_unknown_opcode;
		
		if hay4stk_instr_is_branch(instruction) OR
		(instruction.OpCode = HAY4STK_INSTR_OPCODE_SET AND instruction.LL_Bits = "11") OR
		(instruction.OpCode = HAY4STK_INSTR_OPCODE_CLR AND instruction.LL_Bits = "10") OR
		instruction.OpCode = HAY4STK_INSTR_OPCODE_LD_PTR OR 
		instruction.OpCode = HAY4STK_INSTR_OPCODE_LDI
		then
			--Go directly to phase5
			output_state := st_phase5;
		else
			--Immediate and ALU Operations
			output_state := st_phase2;
		end if;
		
		if 
		instruction.OpCode = HAY4STK_INSTR_OPCODE_CALL
		then
			--CALL and RTN (they share the same OpCode)
			output_state := st_phase3;
		end if;

		return output_state;
	end function hay4stk_instr_decode_state_ph1;

	--Decode State in phase2
	function hay4stk_instr_decode_state_ph2 	(instruction:hay4stk_instruction_rtype) 	return hay4stk_control_machine_state_type is
	variable output_state : hay4stk_control_machine_state_type;
	begin
	
		output_state := st_unknown_opcode;
		
		if hay4stk_instr_is_imm(instruction)
		then
			--Immediates go to phase5
			output_state := st_phase5;
		else
			--ALU Operations
			output_state := st_phase3;
		end if;
		
		return output_state;
	end function hay4stk_instr_decode_state_ph2;

	function hay4stk_instr_main_mem_we 	(instruction : hay4stk_instruction_rtype) 	return std_logic is
	variable return_we : std_logic;
	begin
		return_we := '1'; --default is to write to memory, as there are very few instructions that do not
	
		if hay4stk_instr_is_branch(instruction) then
			--None of the branch instructions write to memory
			return_we := '0';
		else
			case instruction.OpCode is
				when 
				HAY4STK_INSTR_OPCODE_BIT|HAY4STK_INSTR_OPCODE_CMP| --also HAY4STK_INSTR_OPCODE_CMPI,HAY4STK_INSTR_OPCODE_BITI but it is repeated
				HAY4STK_INSTR_OPCODE_LD_PTR|
				HAY4STK_INSTR_OPCODE_JMP_RTN
				=> return_we := '0';
				when HAY4STK_INSTR_OPCODE_RTN =>
					if hay4stk_instr_is_imm(instruction) then
						--Do not update RAM in RETURN instruction
						return_we := '0';
					end if;
				
				when others	=> return_we := '1';
			end case;
		end if;
		
		return return_we;
	end function hay4stk_instr_main_mem_we;

	--Given the Instruction Register (IR) decode the ALU controls
	function hay4stk_alu_decode 	(instruction:hay4stk_instruction_rtype;
									 CCR_Reg:hay4stk_ccr_rtype)
									return hay4stk_alu_ctrl_rtype is
	variable output_alu_ctrls 		: hay4stk_alu_ctrl_rtype;
	begin
		
		--Defaults for all instructions
		output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 	--Select Op2
		output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 	--Select 0
		output_alu_ctrls.nBool_Ctrl 		:= "0"; 						--Do not invert
		output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP2; 		--Select OP2
		output_alu_ctrls.Mult_Sgn_extend 	:= "0"; 						--Do not sign extend
		output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 		--Select ALU output
		output_alu_ctrls.Cin 				:= '0'; 						--Select ALU Carry Input

		case instruction.OpCode is
		
			when HAY4STK_INSTR_OPCODE_LDI =>
			
				--Pass Op2, it should contain "N"
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2;	--Select Op2 (N)
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 	--Select 0
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 						--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP2; 		--Select Op2
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU;  	--Select ALU output
			
			when HAY4STK_INSTR_OPCODE_CMP|HAY4STK_INSTR_OPCODE_SUB => --Also HAY4STK_INSTR_OPCODE_CMPI,HAY4STK_INSTR_OPCODE_SUBI but is repeated
			
				--Op1-N
				--Op1-Op2
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 			--Select Op2
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP1; 			--Select Op1
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 				--Select ALU output
				output_alu_ctrls.Cin 				:= '1';				 					--Carry Input (twos complement)
				if instruction.R_bits = "1" then 	
					--Reverse instruction (Op2-Op1)
					output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX; 	--Select Op2_EAR_Mux
					output_alu_ctrls.nBool_Ctrl 		:= "1"; 								--Invert Op1
				else
					--Normal instruction (Op1-Op2)
					output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_NOP2SELMUX; 	--Select NOT(Op2_EAR_Mux)
					output_alu_ctrls.nBool_Ctrl 		:= "0"; 								--Do not invert Op1
				end if;
				
			when HAY4STK_INSTR_OPCODE_XOR => --Also HAY4STK_INSTR_OPCODE_XORI but is repeated
				
				--N^Op1
				--Op2^Op1
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2;	--Select Op2 (N)
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 	--Select 0
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 						--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_1XOR2; 	--Select Op1^Op2
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 		--Select ALU output
				
			when HAY4STK_INSTR_OPCODE_BIT|HAY4STK_INSTR_OPCODE_AND => --Also HAY4STK_INSTR_OPCODE_ANDI,HAY4STK_INSTR_OPCODE_BITI but is repeated
				
				--N&Op1
				--Op2&Op1
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 	--Select Op2 (N)
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 	--Select 0
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 						--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_1AND2; 	--Select Op1&Op2
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 		--Select ALU output
				
				
			when HAY4STK_INSTR_OPCODE_INC => --Also HAY4STK_INSTR_OPCODE_DEC,HAY4STK_INSTR_OPCODE_CLR,HAY4STK_INSTR_OPCODE_SET but is repeated
				
				--Op2+1
				--Op2-1
				--M(Op2)=0
				--M(Op2)=-1
				
				case instruction.LL_Bits is
					when "00" => --INC
						output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 		--Select Op2
						output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_1; 		--Select 1
						output_alu_ctrls.nBool_Ctrl 		:= "0"; 							--Do not invert
						output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP2; 			--Select Op2
						output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 			--Select ALU output
						output_alu_ctrls.Cin 				:= '0'; 							--No Cin
					when "01" => --DEC
						output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 		--Select Op2
						output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX; --Select Op2
						output_alu_ctrls.nBool_Ctrl 		:= "1"; 							--Invert, obtain -1
						output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_0; 			--Select 0
						output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 			--Select ALU output
						output_alu_ctrls.Cin 				:= '0'; 							--No Cin
					when "10" => --CLEAR
						output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 		--Select Op2
						output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 		--Select 0
						output_alu_ctrls.nBool_Ctrl 		:= "0"; 							--Do not Invert
						output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_0; 			--Select 0
						output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 			--Select ALU output
						output_alu_ctrls.Cin 				:= '0'; 							--No Cin
					when "11" => --SET
						output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 		--Select Op2
						output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 		--Select 0
						output_alu_ctrls.nBool_Ctrl 		:= "1"; 							--Invert 0, obtain -1
						output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_0; 			--Select 0
						output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 			--Select ALU output
						output_alu_ctrls.Cin 				:= '0'; 							--No Cin
					when others =>
						output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 		--Select Op2
						output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_1; 		--Select 1
						output_alu_ctrls.nBool_Ctrl 		:= "0"; 							--Do not invert
						output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP2; 		--Select Op2
						output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 			--Select ALU output
						output_alu_ctrls.Cin 				:= '0'; 							--No Cin
				end case;
				
				
			when HAY4STK_INSTR_OPCODE_ANDN => --Also HAY4STK_INSTR_OPCODE_ANDNI
				
				--N&~Op1
				--Op2&~Op1
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 	--Select Op2
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0;	--Select 0
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 						--Do not invert
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 		--Select ALU output
				if instruction.R_bits = "1" then 	
					--Reverse instruction
					output_alu_ctrls.Bool_Ctrl 		:= HAY4STK_ALU_BOOLCTRL_1AND2N;	--Select ~Op2&Op1
				else
					--Normal instruction
					output_alu_ctrls.Bool_Ctrl 		:= HAY4STK_ALU_BOOLCTRL_N1AND2;	--Select ~Op1&Op2
				end if;
				
			when HAY4STK_INSTR_OPCODE_OR => --Also HAY4STK_INSTR_OPCODE_ORI
				
				--N|Op1
				--Op2|Op1
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2;	--Select Op2
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_0; 	--Select 0
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 						--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_1OR2;  	--Select Op1|Op2
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 		--Select ALU output
				
			when HAY4STK_INSTR_OPCODE_ADD => --Also HAY4STK_INSTR_OPCODE_ADDI
				
				--N+Op1
				--Op2+Op1
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2;			--Select Op2
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX; 	--Select Op2 EAR mux output
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 								--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP1; 				--Select Op1
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 				--Select ALU output

			when HAY4STK_INSTR_OPCODE_ADC => --Also HAY4STK_INSTR_OPCODE_ADCI
				
				--N+Op1+Carry
				--Op2+Op1+Carry
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 			--Select Op2
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX; 	--Select Op2 EAR mux output
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 								--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP1; 			--Select Op1
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 				--Select ALU output
				output_alu_ctrls.Cin 				:= CCR_Reg.carry(0);					--Select ALU Carry Input

			when HAY4STK_INSTR_OPCODE_SBC => --Also HAY4STK_INSTR_OPCODE_SBCI
			
				--Op1-N-Carry
				--Op1-Op2-Carry
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 			--Select Op2
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP1; 			--Select Op1
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 				--Select ALU output
				output_alu_ctrls.Cin 				:= CCR_Reg.carry(0); 					--Carry Input (from LS word)
				if instruction.R_bits = "1" then 	
					--Reverse instruction (Op2-Op1)
					output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX; 	--Select Op2_EAR_Mux
					output_alu_ctrls.nBool_Ctrl 		:= "1"; 								--Invert Op1
				else
					--Normal instruction (Op1-Op2)
					output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_NOP2SELMUX; 	--Select NOT(Op2_EAR_Mux)
					output_alu_ctrls.nBool_Ctrl 		:= "0"; 								--Do not invert Op1
				end if;
				
			when HAY4STK_INSTR_OPCODE_MUL => --Also HAY4STK_INSTR_OPCODE_MULI
				
				--N*Op1
				--Op2*Op1
				output_alu_ctrls.Mult_Sgn_extend 	:= "0"; 						--Do not sign extend
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_MULTLO; 	--Select Mult output LO
				
			when HAY4STK_INSTR_OPCODE_MULUU => --Also HAY4STK_INSTR_OPCODE_MULUUI
				
				--(N*op1)>>16
				--(Op2*op1)>>16
				output_alu_ctrls.Mult_Sgn_extend 	:= "0"; 						--Do not sign extend
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_MULTHI;	--Select Mult output HI
				
			when HAY4STK_INSTR_OPCODE_MULSU => --Also HAY4STK_INSTR_OPCODE_MULSUI
				
				--(N*op1)>>>16 (Signed Multiplication)
				--(Op2*op1)>>>16 (Signed Multiplication)
				output_alu_ctrls.Mult_Sgn_extend 	:= "1"; 						--Sign extend
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_MULTHI;	--Select Mult output HI

			when HAY4STK_INSTR_OPCODE_CALL =>
				
				--Select EAR+1
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_EAR; 			--Select EAR
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_1; 			--Select 1
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP2; 			--Select Op2
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 								--Do not invert
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 				--Select ALU output
				output_alu_ctrls.Cin 				:= '0'; 								--No Cin
				
			when others =>
				--Defaults
				output_alu_ctrls.Op2_EAR_mux_sel 	:= HAY4STK_ALU_OP2EARMUX_OP2; 			--Select Op2
				output_alu_ctrls.Op2_Ctrl_mux_sel 	:= HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX; 	--Select Op2 EAR mux output
				output_alu_ctrls.nBool_Ctrl 		:= "0"; 								--Do not invert
				output_alu_ctrls.Bool_Ctrl 			:= HAY4STK_ALU_BOOLCTRL_OP2; 			--Select OP2
				output_alu_ctrls.Mult_Sgn_extend 	:= "0"; 								--Do not sign extend
				output_alu_ctrls.DID_sel 			:= HAY4STK_ALU_DIDMUX_ALU; 				--Select ALU output
				output_alu_ctrls.Cin 				:= '0';									--Select ALU Carry Input
			
		end case;
		
		return output_alu_ctrls;
	end function hay4stk_alu_decode;
	
	function hay4stk_instr_is_alu 	(instruction : hay4stk_instruction_rtype) return boolean is
	begin
		--Check if instruction belong to ALU subset
		if NOT(hay4stk_instr_is_imm(instruction)) AND
		   NOT(hay4stk_instr_is_branch(instruction))
			then
			return TRUE;
		end if;
		return FALSE;
	end function hay4stk_instr_is_alu;
	
	function hay4stk_instr_is_imm 	(instruction : hay4stk_instruction_rtype) return boolean is
	begin
		--Check if instruction belong to immediate subset
		if instruction.R_bits = "0" AND instruction.T_bits = "1" AND (instruction.M_bits = "111" OR instruction.M_bits = "110") then
			return TRUE;
		end if;
		return FALSE;
	end function hay4stk_instr_is_imm;
	
	function hay4stk_instr_is_branch 	(instruction : hay4stk_instruction_rtype) return boolean is
	begin
		--Check if instruction belong to Branch subset
		if instruction.R_bits = "1" AND instruction.T_bits = "1" AND (instruction.M_bits = "111" OR instruction.M_bits = "110") then
			return TRUE;
		end if;
		return FALSE;
	end function hay4stk_instr_is_branch;
	
	function hay4stk_instr_is_ctrl 	(instruction : hay4stk_instruction_rtype) return boolean is
	begin
		--Check if instruction belong to Control subset
		if hay4stk_instr_is_branch(instruction) OR instruction.OpCode = HAY4STK_INSTR_OPCODE_CALL OR instruction.OpCode =  HAY4STK_INSTR_OPCODE_RTN then
			return TRUE;
		end if;
		return FALSE;
	end function hay4stk_instr_is_ctrl;
	
	-- function hay4stk_instr_is_ldst 	(instruction : hay4stk_instruction_rtype) return boolean is
	-- begin
		-- if instruction.R_bits = "1" AND instruction.T_bits = "1" AND (instruction.M_bits = "111" OR instruction.M_bits = "110") then
			-- return TRUE;
		-- end if;
		-- return FALSE;
	-- end function hay4stk_instr_is_branch;
	
	-- ------------------------------------------------------------
	-- ------------------------------------------------------------
	-- --CCR and Branch Stuff
	-- ------------------------------------------------------------
	-- ------------------------------------------------------------
	
	function hay4stk_alu_ccr_decode 	(alu_data_in:hay4stk_operand_data_type;
										 alu_Cout		: std_logic;
										 alu_Overflow	: std_logic)
										 return hay4stk_ccr_rtype is
	variable output_ccr_rtype_var 		: hay4stk_ccr_rtype;
	begin
		
		-- output_ccr_rtype_var := (others => (others => '0')); --There seems to be a problem with statement, simulation crashes
		
		--Set all to zero
		output_ccr_rtype_var.carry 			:= (others => '0');
		output_ccr_rtype_var.overflow		:= (others => '0');
		output_ccr_rtype_var.negative 		:= (others => '0');
		output_ccr_rtype_var.zero 			:= (others => '0');
		output_ccr_rtype_var.odd 			:= (others => '0');
		output_ccr_rtype_var.parity			:= (others => '0');
		output_ccr_rtype_var.interrupt_en	:= (others => '0');
		output_ccr_rtype_var.br_taken		:= (others => '0');
		
		--Check Carry Bit
		output_ccr_rtype_var.carry(0) 	  	:= alu_Cout;
		
		--Check Zero Bit
		output_ccr_rtype_var.zero(0) 		:= NOT(or_reduce(alu_data_in));
		
		--Check Negative Bit (sign bit)
		output_ccr_rtype_var.negative(0) 	:= alu_data_in(alu_data_in'high);
		
		--Check Odd bit
		output_ccr_rtype_var.odd(0) 		:= alu_data_in(alu_data_in'low);
		
		--Parity Flag. XOR Operation gives a '0' if number of '1's is even, and a '1' if the number of '1's is odd
		output_ccr_rtype_var.parity(0) 		:= xor_reduce(alu_data_in);
		
		--Overflow Flag.
		--If sign bits of both operands are the same and the result is a different sign then there is overflow
		output_ccr_rtype_var.overflow(0) 	:= alu_Overflow;
		
		return output_ccr_rtype_var;
	end function hay4stk_alu_ccr_decode;
	
	function hay4stk_ccr_branch_decode 	(	instruction  : hay4stk_instruction_rtype;
											ccr_data_in  : hay4stk_ccr_rtype	)
											return std_logic is
	variable branch_taken		: std_logic;
	begin
		
		branch_taken := '0'; --default is branch not taken
		
		--See MSP430 instruction set
		
		if hay4stk_instr_is_branch(instruction) then 	--if it is a branch instruction
			case instruction.OpCode is 					--depending on OpCode
			
				when HAY4STK_INSTR_OPCODE_BR_NOP 	=>	branch_taken := '1';
				
				when HAY4STK_INSTR_OPCODE_BROD_BREV =>
					if ccr_data_in.odd = "1" then
						branch_taken := '1';
					end if;
					
				when HAY4STK_INSTR_OPCODE_BRZ_BRNZ 	=>
					if ccr_data_in.zero = "1" then
						branch_taken := '1';
					end if;
					
				when HAY4STK_INSTR_OPCODE_BRCS_BRCC =>
					if ccr_data_in.carry = "1" then
						branch_taken := '1';
					end if;

				when HAY4STK_INSTR_OPCODE_BROV_BRNOV =>
					if ccr_data_in.overflow = "1" then
						branch_taken := '1';
					end if;
					
				when HAY4STK_INSTR_OPCODE_BRM_BRP =>
					if ccr_data_in.negative = "1" then
						branch_taken := '1';
					end if;
					
				when HAY4STK_INSTR_OPCODE_BRGE_BRLT =>
					if (ccr_data_in.negative(0) XOR ccr_data_in.overflow(0))  = '0' then --If greater than or equal (signed)
						branch_taken := '1';
					end if;
					
				when HAY4STK_INSTR_OPCODE_BRGT_BRLE =>
					if (ccr_data_in.negative(0) XOR ccr_data_in.overflow(0))  = '0' AND ccr_data_in.zero = "0" then --If greater than  (signed)
						branch_taken := '1';
					end if;
					
				when HAY4STK_INSTR_OPCODE_BRHI_BRLS =>
					if ccr_data_in.carry = "1" then --If higher than or equal (unsigned)
						branch_taken := '1';
					end if;
				
				--Default is HAY4STK_INSTR_OPCODE_BR_NOP
				when others =>	branch_taken := '1';					
			end case;
			
			--M(0) inverts the condition of the branch if set
			branch_taken := branch_taken XOR instruction.M_bits(0);
			
		end if;
		
		return branch_taken;
	end function hay4stk_ccr_branch_decode;
	
	function hay4stk_ccr_we_decode 	(	instruction : hay4stk_instruction_rtype	)
										return std_logic is
	variable ccr_we		: std_logic;
	begin
		ccr_we := '0'; --default
		--Branches do not write
		
		if hay4stk_instr_is_imm(instruction) then
			--Immediates
			ccr_we := '1';	--Default for this instruction type is to update CCR
			case instruction.OpCode is
				when 
				HAY4STK_INSTR_OPCODE_LDI
							=> 	ccr_we := '0';				
				when others =>	ccr_we := '1';
			end case;
		elsif hay4stk_instr_is_alu(instruction) then
			--ALU instructions
			ccr_we := '1';	--Default for this instruction type is to update CCR
			case instruction.OpCode is
				when 
				HAY4STK_INSTR_OPCODE_LD_PTR
							=> 	ccr_we := '0';
				when others =>	ccr_we := '1';
			end case;
		end if;
		
		return ccr_we;
	end function hay4stk_ccr_we_decode;

end hay4stk_ctrl_pkg;