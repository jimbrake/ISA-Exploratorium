----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- 
-- Create Date:		             
-- Design Name:		                                        
-- Module Name:		    hay4stk_top.vhd
-- Project Name:		hay4stk16_32
-- Target Devices: 
-- Tool versions: 
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
--USE hay4stk.hay4stk_defs_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;
USE work.hay4stk_defs_pkg.ALL;

entity hay4stk_top is
port
(
	reset				: in std_logic; --Sync Reset
	clk					: in std_logic; --Clk input
	external_input		: in hay4stk_operand_data_type; --External Data Input
	DID_out_regd		: out hay4stk_operand_data_type;
 	ALU_ctrl_cpy		: out hay4stk_alu_ctrl_rtype; 	--
 	ALU_Op1_Reg_cpy		: out hay4stk_operand_data_type; 	--
 	ALU_Op2_Reg_cpy		: out hay4stk_operand_data_type;
	to_main_mem_cpy  	: out hay4stk_main_mem_inputs_rtype;
	from_main_mem_cpy	: out hay4stk_main_mem_outputs_rtype
);
-- Keep Everything from being optimized out
-- attribute KEEP_HIERARCHY : string;
-- attribute KEEP_HIERARCHY of hay4stk_top : entity is "TRUE";
end hay4stk_top;
    
architecture RTL of hay4stk_top is

	-------
	signal 	ALU_ctrl			:  hay4stk_alu_ctrl_rtype; 	--
	signal 	ALU_Op1_Reg			:  hay4stk_operand_data_type; 	--
	signal 	ALU_Op2_Reg			:  hay4stk_operand_data_type;
	
	signal 	ALU_DID_mux_out		:  std_logic_vector(16-1 downto 0); 	--
	signal 	ALU_Result			:  hay4stk_operand_data_type; 	--
	signal 	ALU_Cout			:  std_logic;
	signal 	Overflow_out		:  std_logic;
	-------
	signal  N_Reg				: hay4stk_operand_data_type;
	signal  Op1_Reg				: hay4stk_operand_data_type;
	signal  Op2_Reg				: hay4stk_operand_data_type;
	-------	
	signal 	addr_gen_ctrl		:  hay4stk_addrgen_ctrl_rtype;
	signal 	addr_gen_EAR_Reg	:  hay4stk_Addrgen_RAM_data_type;
	signal 	addr_gen_addr		:  hay4stk_Addrgen_RAM_data_type;
	-------
	signal 	to_main_mem  		:  hay4stk_main_mem_inputs_rtype;
	signal 	from_main_mem		:  hay4stk_main_mem_outputs_rtype;
	signal  DID_out				:  hay4stk_operand_data_type;
	-------
--	signal 	addr_bus_out		:  hay4stk_address_bus_type;

begin

 	ALU_ctrl_cpy		<= ALU_ctrl;
 	ALU_Op1_Reg_cpy 	<= ALU_Op1_Reg;
 	ALU_Op2_Reg_cpy 	<= ALU_Op2_Reg;
	to_main_mem_cpy		<= to_main_mem;
	from_main_mem_cpy	<= from_main_mem;

	Inst_hay4stk_addr_gen : entity work.hay4stk_addr_gen
	port map
	(
		reset				=> reset,
		clk					=> clk,
		
		addr_gen_ctrl_in	=> addr_gen_ctrl,
		EAR_Reg_out			=> addr_gen_EAR_Reg,
		Addr_out			=> addr_gen_addr
	);
	
	Inst_hay4stk_main_mem : entity work.hay4stk_main_mem
	port map
	(
		reset				=> reset,
		clk					=> clk,
		
--		main_mem_addr_in	=> addr_bus_out(hay4stk_main_mem_addr_type'range),
		main_mem_in			=> to_main_mem,
		main_mem_out		=> from_main_mem
	);
	
	Inst_hay4stk_alu : entity work.hay4stk_alu
	port map
	(
		reset				=> reset,
		clk					=> clk,
		
		alu_ctrl_in			=> ALU_ctrl,
		Op1_Reg				=> Op1_reg,
		Op2_Reg				=> Op2_reg,
		EAR_Reg				=> addr_gen_EAR_Reg,
		DID_out				=> ALU_DID_mux_out,
		ALU_out				=> ALU_Result,
		Overflow_out		=> Overflow_out,
		Cout				=> ALU_Cout
	);
	
	--DID_out needs to be registered
	DID_REG_PROC:process(clk)
	begin
		if rising_edge(clk) then
--			if to_main_mem.we_hi = '1' AND addr_bus_out(addr_bus_out'high) = '1' then
--				DID_out <= ALU_DID_mux_out;
			if to_main_mem.we_hi = '1' AND to_main_mem.addr(15-1) = '1' then
				DID_out_regd <= DID_out;
			end if;
		end if;
	end process;
	
	Inst_hay4stk_control : entity work.hay4stk_control
	port map
	(
		reset				=> reset,
		clk					=> clk,
		--
		from_main_mem		=> from_main_mem,
		to_main_mem			=> to_main_mem,
		--
		Op1_reg_out			=> Op1_reg,
		Op2_reg_out			=> Op2_reg,
		N_reg_out			=> N_reg,
		--
		external_input		=> external_input,
		--
--		addr_bus_out		=> addr_bus_out,
		--
		alu_did_mux_in		=> ALU_DID_mux_out,
		alu_ctrl_out		=> alu_ctrl,
		alu_Cout			=> ALU_Cout, --FROM ALU
		alu_Overflow		=> Overflow_out, --FROM ALU
		--
		addr_gen_data_in	=> addr_gen_addr,
		addr_gen_ctrl_out	=> addr_gen_ctrl
	);
	
end RTL;