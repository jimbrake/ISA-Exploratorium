----------------------------------------------------------------------------------
-- Original Idea and architecture:		James Brakefield
-- Engineer (Code):						Leonardo Capossio
-- Description:		                                                                               
--		HYbrid architecture Accumulator and Addressable STacK processor
--		Four accumulators and associated stacks, 16-bit data, 32-bit instructions
--		Accumulators reside on the stacks and are at the stack pointer location
--		In general stacks may be ascending or descending (D=0 or D=1), here D="1111"
--		Stack 0 is used to hold "default stack" return addresses
--		16-bit data only, 32-bit instructions only
--

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

LIBRARY hay4stk;
--USE hay4stk.hay4stk_utils_pkg.ALL;
USE work.hay4stk_utils_pkg.ALL;

package hay4stk_defs_pkg is

	--**Constants**
	constant HAY4STK_NUM_STACKS			: integer := 4;
	constant HAY4STK_STACK_ADDR_BITS	: integer := clog2(HAY4STK_NUM_STACKS);
	constant MAIN_MEM_SIZE 				: integer := 512;
	
	--**General**
	subtype hay4stk_operand_data_type  is std_logic_vector(16-1 downto 0);
	subtype hay4stk_address_bus_type   is std_logic_vector(16-1 downto 0);
	
	--**Address RAM**
--	subtype hay4stk_Addrgen_RAM_data_type is std_logic_vector(hay4stk_address_bus_type'length-1 downto 0);
	subtype hay4stk_Addrgen_RAM_data_type 	is std_logic_vector(16-1 downto 0);
	type hay4stk_Addrgen_RAM_type 			is array(8-1 downto 0) of hay4stk_Addrgen_RAM_data_type;
	subtype hay4stk_Addrgen_RAM_addr_type 	is std_logic_vector(clog2(hay4stk_Addrgen_RAM_type'length)-1 downto 0);
	
	--**MAIN Memory**
	subtype hay4stk_main_mem_data_type is std_logic_vector(32-1 downto 0);
	subtype hay4stk_main_mem_hi_data_type is std_logic_vector(16-1 downto 0);
	subtype hay4stk_main_mem_lo_data_type is std_logic_vector(16-1 downto 0);
	
	type hay4stk_main_mem_type is array(MAIN_MEM_SIZE-1 downto 0) of hay4stk_main_mem_data_type;
	type hay4stk_main_data_mem_type is array(MAIN_MEM_SIZE*2-1 downto 0) of hay4stk_operand_data_type; --Simulation only (does not get synthesized)
--	subtype hay4stk_main_mem_addr_type is std_logic_vector(clog2(hay4stk_main_mem_type'length)-1 downto 0);
	subtype hay4stk_main_mem_addr_type 	is std_logic_vector(15-1 downto 0);

--	type hay4stk_main_mem_inputs_rtype is record
--		we_hi			 		 :  std_logic; 						--Write enable for High 16-bits
--		we_lo			 		 :  std_logic; 						--Write enable for Low 16-bits
--		din			 		 	 :  hay4stk_main_mem_data_type; 	--
--	end record hay4stk_main_mem_inputs_rtype;
	type hay4stk_main_mem_inputs_rtype is record
		addr			 	 :  hay4stk_main_mem_addr_type; 	--
		we_hi			 	 :  std_logic; 						--Write enable for High 16-bits
		we_lo			 	 :  std_logic; 						--Write enable for Low 16-bits
		din			 		 :  hay4stk_main_mem_data_type; 	--
	end record hay4stk_main_mem_inputs_rtype;
	
	type hay4stk_main_mem_outputs_rtype is record
		dout_hi					:  hay4stk_main_mem_hi_data_type; --
		dout_lo					:  hay4stk_main_mem_lo_data_type; --
	end record hay4stk_main_mem_outputs_rtype;
	
	

	--*****************************
	--**AddrGen-related Stuff**
	
	constant HAY4STK_PC_START_ADDR 			: hay4stk_Addrgen_RAM_data_type := to_unsigned_slv(0,hay4stk_Addrgen_RAM_data_type'length);
	constant HAY4STK_ADDRGEN_RAM_SP0_ADDR 	: hay4stk_Addrgen_RAM_addr_type := "000";--0
	constant HAY4STK_ADDRGEN_RAM_FP_ADDR 	: hay4stk_Addrgen_RAM_addr_type := "100";--4
	constant HAY4STK_ADDRGEN_RAM_TP_ADDR 	: hay4stk_Addrgen_RAM_addr_type := "101";--5
	constant HAY4STK_ADDRGEN_RAM_PC_ADDR 	: hay4stk_Addrgen_RAM_addr_type := "110";--6
	constant HAY4STK_ADDRGEN_RAM_0_ADDR 	: hay4stk_Addrgen_RAM_addr_type := "111";--7
	
	subtype hay4stk_addrgen_ctrl_addrsel_type is std_logic_vector(2-1 downto 0);
	constant HAY4STK_ADDRGEN_CTRL_ADDRSEL_0_SPN 				: hay4stk_addrgen_ctrl_addrsel_type := "00";
	constant HAY4STK_ADDRGEN_CTRL_ADDRSEL_1_SPN 				: hay4stk_addrgen_ctrl_addrsel_type := "01";
	constant HAY4STK_ADDRGEN_CTRL_ADDRSEL_M_BITS 				: hay4stk_addrgen_ctrl_addrsel_type := "10";
	constant HAY4STK_ADDRGEN_CTRL_ADDRSEL_PC					: hay4stk_addrgen_ctrl_addrsel_type := "11";
	--
	subtype hay4stk_addrgen_ctrl_Addrgen_mux_type is std_logic_vector(2-1 downto 0);
	constant HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_EAR 				: hay4stk_addrgen_ctrl_Addrgen_mux_type := "00";
	constant HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_ADDR_ALU 			: hay4stk_addrgen_ctrl_Addrgen_mux_type := "01";
	constant HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_MAIN_MEM_HI 		: hay4stk_addrgen_ctrl_Addrgen_mux_type := "10";
	constant HAY4STK_ADDRGEN_CTRL_ADDRGEN_MUX_MAIN_MEM_LO		: hay4stk_addrgen_ctrl_Addrgen_mux_type := "11";
	--
	subtype hay4stk_addrgen_ctrl_ear_mux_type is std_logic_vector(1-1 downto 0);
	constant HAY4STK_ADDRGEN_CTRL_EAR_MUX_RAM 					: hay4stk_addrgen_ctrl_ear_mux_type := "0";
	constant HAY4STK_ADDRGEN_CTRL_EAR_MUX_EAR			 		: hay4stk_addrgen_ctrl_ear_mux_type := "1";
	--
	subtype hay4stk_addrgen_ctrl_delta_mux_type is std_logic_vector(2-1 downto 0);
	constant HAY4STK_ADDRGEN_CTRL_DELTA_MUX_0 					: hay4stk_addrgen_ctrl_delta_mux_type := "00"; --  0
	constant HAY4STK_ADDRGEN_CTRL_DELTA_MUX_1 					: hay4stk_addrgen_ctrl_delta_mux_type := "01"; -- +1
	constant HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N1 				: hay4stk_addrgen_ctrl_delta_mux_type := "10"; -- -1
	constant HAY4STK_ADDRGEN_CTRL_DELTA_MUX_N					: hay4stk_addrgen_ctrl_delta_mux_type := "11"; --  N
	--
	subtype hay4stk_addrgen_ctrl_addrsel_mux_type is std_logic_vector(1-1 downto 0);
	constant HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_OP2 				: hay4stk_addrgen_ctrl_addrsel_mux_type := "0";
	constant HAY4STK_ADDRGEN_CTRL_ADDRSEL_MUX_EARMUX		 	: hay4stk_addrgen_ctrl_addrsel_mux_type := "1";
	
	type hay4stk_addrgen_ctrl_rtype is record
		EAR_we			 		 	 :  std_logic_vector(1-1 downto 0); --
		EAR_sel			 		 	 :  hay4stk_addrgen_ctrl_ear_mux_type; --
		Delta_sel		 		 	 :  hay4stk_addrgen_ctrl_delta_mux_type; --
		N_in						 :  hay4stk_operand_data_type;  --
		M_bits			 		 	 :  std_logic_vector(3-1 downto 0); --
		Addr_sel		 		 	 :  hay4stk_addrgen_ctrl_addrsel_mux_type; --
		Op2_in					 	 :  hay4stk_operand_data_type;  --
		Addrgen_mux_sel				 :  hay4stk_addrgen_ctrl_Addrgen_mux_type;  --
		SPn_sel					 	 :  std_logic_vector(2-1 downto 0);  --
		--Addr RAM controls
		WrAddr_sel		 		 	 :  hay4stk_addrgen_ctrl_addrsel_type; --
		RdAddr_sel		 		 	 :  hay4stk_addrgen_ctrl_addrsel_type; --
		Addrgen_RAM_wr_en	 		 :  std_logic_vector(1-1 downto 0); --
		--
		--Inputs from MAIN RAM
		Main_MEM_hi16			 	 :  hay4stk_main_mem_hi_data_type;  --
		Main_MEM_lo16			 	 :  hay4stk_main_mem_lo_data_type;  --
	end record hay4stk_addrgen_ctrl_rtype;

	--*****************************
	--**ALU-related Stuff**
	
	subtype hay4stk_alu_op2_ear_mux_type is std_logic_vector(1-1 downto 0);
	constant HAY4STK_ALU_OP2EARMUX_EAR 					: hay4stk_alu_op2_ear_mux_type := "0"; -- 
	constant HAY4STK_ALU_OP2EARMUX_OP2 					: hay4stk_alu_op2_ear_mux_type := "1"; --
	
	subtype hay4stk_alu_op2_ctrl_mux_type is std_logic_vector(2-1 downto 0);
	constant HAY4STK_ALU_OP2CTRLMUX_0 					: hay4stk_alu_op2_ctrl_mux_type := "00"; -- 
	constant HAY4STK_ALU_OP2CTRLMUX_OP2SELMUX 			: hay4stk_alu_op2_ctrl_mux_type := "01"; --
	constant HAY4STK_ALU_OP2CTRLMUX_NOP2SELMUX 			: hay4stk_alu_op2_ctrl_mux_type := "10"; --
	constant HAY4STK_ALU_OP2CTRLMUX_1					: hay4stk_alu_op2_ctrl_mux_type := "11"; --
	
	subtype hay4stk_alu_did_mux_type is std_logic_vector(2-1 downto 0);
	constant HAY4STK_ALU_DIDMUX_ALU 					: hay4stk_alu_did_mux_type := "00"; -- 
	constant HAY4STK_ALU_DIDMUX_SPARE					: hay4stk_alu_did_mux_type := "01"; --
	constant HAY4STK_ALU_DIDMUX_MULTLO 					: hay4stk_alu_did_mux_type := "10"; --
	constant HAY4STK_ALU_DIDMUX_MULTHI					: hay4stk_alu_did_mux_type := "11"; --
	
	--Bool_ctrl: zero, and, 1andn2, n1and2, or, xor, op1, op2
	subtype  hay4stk_alu_boolctrl_type 		is std_logic_vector(3-1 downto 0);
	constant HAY4STK_ALU_BOOLCTRL_1AND2 		: hay4stk_alu_boolctrl_type := "000";
	constant HAY4STK_ALU_BOOLCTRL_1AND2N 		: hay4stk_alu_boolctrl_type := "001";
	constant HAY4STK_ALU_BOOLCTRL_N1AND2 		: hay4stk_alu_boolctrl_type := "010";
	constant HAY4STK_ALU_BOOLCTRL_1OR2	 		: hay4stk_alu_boolctrl_type := "011";
	constant HAY4STK_ALU_BOOLCTRL_1XOR2	 		: hay4stk_alu_boolctrl_type := "100";
	constant HAY4STK_ALU_BOOLCTRL_OP1		 	: hay4stk_alu_boolctrl_type := "101";
	constant HAY4STK_ALU_BOOLCTRL_OP2		 	: hay4stk_alu_boolctrl_type := "110";
	constant HAY4STK_ALU_BOOLCTRL_0		 		: hay4stk_alu_boolctrl_type := "111";
	
	--Inputs for "hay4stk_alu" block
	type hay4stk_alu_ctrl_rtype is record
		Op2_EAR_mux_sel			 	 :  hay4stk_alu_op2_ear_mux_type; --
		Op2_Ctrl_mux_sel		 	 :  hay4stk_alu_op2_ctrl_mux_type; --
		nBool_Ctrl		 		 	 :  std_logic_vector(1-1 downto 0); --
		Bool_Ctrl		 		 	 :  hay4stk_alu_boolctrl_type; --
		Mult_Sgn_extend	 		 	 :  std_logic_vector(1-1 downto 0); --
		DID_sel			 		 	 :  hay4stk_alu_did_mux_type; --
		Cin				 		 	 :  std_logic; --
	end record hay4stk_alu_ctrl_rtype;
	
	--*****************************
	--**CCR-related Stuff**
	constant HAY4STK_CCR_LENGTH 		: integer := 8;
	subtype hay4stk_ccr_slv_type 		is std_logic_vector(HAY4STK_CCR_LENGTH-1 downto 0);
	type hay4stk_ccr_ram_type is array (HAY4STK_NUM_STACKS-1 downto 0) 	of hay4stk_ccr_slv_type;
	
	type hay4stk_ccr_rtype is record
		--CCR: SZIN DDDD PPPP OOOO MMMM ZZZZ VVVV CCCC: carry,overflow,
		--zero,negative,odd,parity,stack direction,size,interrupt enable & taken
		carry			 	 :  std_logic_vector(1-1 downto 0); --
		overflow		 	 :  std_logic_vector(1-1 downto 0); --
		negative		 	 :  std_logic_vector(1-1 downto 0); --
		zero	 		 	 :  std_logic_vector(1-1 downto 0); --
		odd		 		 	 :  std_logic_vector(1-1 downto 0); --
		parity	 		 	 :  std_logic_vector(1-1 downto 0); --
		interrupt_en	 	 :  std_logic_vector(1-1 downto 0); --
		br_taken		 	 :  std_logic_vector(1-1 downto 0); --
		--stack_dir		 	 :  std_logic_vector(1-1 downto 0); --
	end record hay4stk_ccr_rtype;
	
	function hay4stk_ccr_slv_to_rtype 	(input_slv:hay4stk_ccr_slv_type) return hay4stk_ccr_rtype;
	function hay4stk_ccr_rtype_to_slv 	(input_rtype:hay4stk_ccr_rtype) return hay4stk_ccr_slv_type;
	
	--*****************************
	--**Instruction-related Stuff**
	
	constant HAY4STK_INSTR_OPCODE_LENGTH 	: integer := 5;
	subtype hay4stk_instr_opcode_slv_type 	is std_logic_vector(HAY4STK_INSTR_OPCODE_LENGTH-1 downto 0);
	
	--Branch Instructions Opcodes
	constant HAY4STK_INSTR_OPCODE_BR_NOP	 	: hay4stk_instr_opcode_slv_type := "10111"; --Branch always/No-Operation
	constant HAY4STK_INSTR_OPCODE_BROD_BREV 	: hay4stk_instr_opcode_slv_type := "11000"; --Branch on Odd/Even
	constant HAY4STK_INSTR_OPCODE_BRZ_BRNZ	 	: hay4stk_instr_opcode_slv_type := "11001"; --Branch on Zero/Not Zero
--	constant HAY4STK_INSTR_OPCODE_BREQ_BRNE		: hay4stk_instr_opcode_slv_type := "11001"; --Branch on Equal/Not Equal alias
	constant HAY4STK_INSTR_OPCODE_BRCS_BRCC		: hay4stk_instr_opcode_slv_type := "11010"; --Branch on Carry Set/Carry Clear
--	constant HAY4STK_INSTR_OPCODE_BRHS_BRLO		: hay4stk_instr_opcode_slv_type := "11010"; --Branch unsigned high-same/low alias
	constant HAY4STK_INSTR_OPCODE_BROV_BRNOV	: hay4stk_instr_opcode_slv_type := "11011"; --branch overflow/no overflow (OV: both operands have same sign & result sign is differen)
	constant HAY4STK_INSTR_OPCODE_BRGE_BRLT		: hay4stk_instr_opcode_slv_type := "11100"; --Branch signed greater-equal/less than (M XOR OV = 0/1)
	constant HAY4STK_INSTR_OPCODE_BRM_BRP	 	: hay4stk_instr_opcode_slv_type := "11101"; --Branch on Negative/Positive
	constant HAY4STK_INSTR_OPCODE_BRGT_BRLE		: hay4stk_instr_opcode_slv_type := "11110"; --Branch signed greater than/less-equal
	constant HAY4STK_INSTR_OPCODE_BRHI_BRLS		: hay4stk_instr_opcode_slv_type := "11111"; --Branch unsigned high/low-same
	
	--Immediate Instructions Opcodes
	constant HAY4STK_INSTR_OPCODE_LDI	 	: hay4stk_instr_opcode_slv_type := "00110";
	constant HAY4STK_INSTR_OPCODE_XORI	 	: hay4stk_instr_opcode_slv_type := "10111";
	constant HAY4STK_INSTR_OPCODE_BITI	 	: hay4stk_instr_opcode_slv_type := "01111";
	constant HAY4STK_INSTR_OPCODE_ANDI	 	: hay4stk_instr_opcode_slv_type := "10100";
	constant HAY4STK_INSTR_OPCODE_ANDNI	 	: hay4stk_instr_opcode_slv_type := "10101";
	constant HAY4STK_INSTR_OPCODE_ORI	 	: hay4stk_instr_opcode_slv_type := "10110";
	constant HAY4STK_INSTR_OPCODE_ADDI	 	: hay4stk_instr_opcode_slv_type := "11000";
	constant HAY4STK_INSTR_OPCODE_SUBI	 	: hay4stk_instr_opcode_slv_type := "11001";
	constant HAY4STK_INSTR_OPCODE_ADCI	 	: hay4stk_instr_opcode_slv_type := "11010";
	constant HAY4STK_INSTR_OPCODE_SBCI	 	: hay4stk_instr_opcode_slv_type := "11011";
	constant HAY4STK_INSTR_OPCODE_MULI	 	: hay4stk_instr_opcode_slv_type := "11101";
	constant HAY4STK_INSTR_OPCODE_MULUUI 	: hay4stk_instr_opcode_slv_type := "11110";
	constant HAY4STK_INSTR_OPCODE_MULSUI 	: hay4stk_instr_opcode_slv_type := "11111";
	constant HAY4STK_INSTR_OPCODE_CMPI	 	: hay4stk_instr_opcode_slv_type := "01110";
	
	--ALU Instructions Opcodes (R version opcode is defined as it is the same)
	constant HAY4STK_INSTR_OPCODE_LD	 	: hay4stk_instr_opcode_slv_type := "00110";
	constant HAY4STK_INSTR_OPCODE_BIT	 	: hay4stk_instr_opcode_slv_type := "01111";
	constant HAY4STK_INSTR_OPCODE_INC	 	: hay4stk_instr_opcode_slv_type := "01100";
	constant HAY4STK_INSTR_OPCODE_DEC	 	: hay4stk_instr_opcode_slv_type := "01100";
	constant HAY4STK_INSTR_OPCODE_SET	 	: hay4stk_instr_opcode_slv_type := "01100";
	constant HAY4STK_INSTR_OPCODE_CLR	 	: hay4stk_instr_opcode_slv_type := "01100";
	constant HAY4STK_INSTR_OPCODE_AND	 	: hay4stk_instr_opcode_slv_type := "10100";
	constant HAY4STK_INSTR_OPCODE_OR	 	: hay4stk_instr_opcode_slv_type := "10110";
	constant HAY4STK_INSTR_OPCODE_XOR	 	: hay4stk_instr_opcode_slv_type := "10111";
	constant HAY4STK_INSTR_OPCODE_ANDN	 	: hay4stk_instr_opcode_slv_type := "10101";
	constant HAY4STK_INSTR_OPCODE_ADD	 	: hay4stk_instr_opcode_slv_type := "11000";
	constant HAY4STK_INSTR_OPCODE_ADC	 	: hay4stk_instr_opcode_slv_type := "11010";
	constant HAY4STK_INSTR_OPCODE_CMP	 	: hay4stk_instr_opcode_slv_type := "01110";
	constant HAY4STK_INSTR_OPCODE_SUB	 	: hay4stk_instr_opcode_slv_type := "11001";
	constant HAY4STK_INSTR_OPCODE_SBC	 	: hay4stk_instr_opcode_slv_type := "11011";
	
	constant HAY4STK_INSTR_OPCODE_MUL	 	: hay4stk_instr_opcode_slv_type := "11101";
	constant HAY4STK_INSTR_OPCODE_MULUU	 	: hay4stk_instr_opcode_slv_type := "11110";
	constant HAY4STK_INSTR_OPCODE_MULSU     : hay4stk_instr_opcode_slv_type := "11111";
	
	--Load/Store Instructions
	constant HAY4STK_INSTR_OPCODE_LD_PTR 	: hay4stk_instr_opcode_slv_type := "00100"; --LSPwEA, LFPwEA, LTPwEA and LPCwEA use the same OpCode
	constant HAY4STK_INSTR_OPCODE_CALL	 	: hay4stk_instr_opcode_slv_type := "00001";
	constant HAY4STK_INSTR_OPCODE_RTN	 	: hay4stk_instr_opcode_slv_type := "00001";
	constant HAY4STK_INSTR_OPCODE_JMP_RTN 	: hay4stk_instr_opcode_slv_type := "00101";

	subtype hay4stk_instruction_slv_type	is std_logic_vector(16-1 downto 0);	
	type hay4stk_instruction_rtype is record
		OpCode			 		 	 :  hay4stk_instr_opcode_slv_type;  -- Op-code
		R_bits			 		 	 :  std_logic_vector(1-1 downto 0);  -- R: if set do a replace operation
		LL_bits			 		 	 :  std_logic_vector(2-1 downto 0);  -- LL: specifies stack pointer register, as in SPn
		SZ_bits			 		 	 :  std_logic_vector(2-1 downto 0);  -- SZ:  Size: 8, 16, 32, 64: here SZ is ignored and size is always 16-bits
		P_bits			 		 	 :  std_logic_vector(1-1 downto 0);  -- P: if set, use stack mode on SPn, if clear use accumulator mode (SPn doesn't change)
		T_bits			 		 	 :  std_logic_vector(1-1 downto 0);  -- T: if set  advance M register by +/-N; T set, R clear and M=7 invokes immediate mode
		return_bit		 		 	 :  std_logic_vector(1-1 downto 0);  -- return_bit: if set return: M(SP0++)=>PC
		M_bits			 		 	 :  std_logic_vector(3-1 downto 0);  -- MMM: Addressing mode, EA, is (SPn|FP|TP|PC|0) +/- N
	end record hay4stk_instruction_rtype;
    
	----------------------------------
	
	function hay4stk_instruction_slv_to_rtype 	(input_slv:hay4stk_instruction_slv_type) 	return hay4stk_instruction_rtype;

end hay4stk_defs_pkg;

package body hay4stk_defs_pkg is

	function hay4stk_instruction_slv_to_rtype 	(input_slv:hay4stk_instruction_slv_type) 	return hay4stk_instruction_rtype is
	variable output_rtype 	: hay4stk_instruction_rtype;
	variable i 				: integer;
	begin
		i := 0;
		output_rtype.M_bits			:= input_slv(i+output_rtype.M_bits'length-1 downto i);		i:=i+output_rtype.M_bits'length;
		output_rtype.return_bit		:= input_slv(i+output_rtype.return_bit'length-1 downto i);	i:=i+output_rtype.return_bit'length;
		output_rtype.T_bits			:= input_slv(i+output_rtype.T_bits'length-1 downto i);		i:=i+output_rtype.T_bits'length;
		output_rtype.P_bits			:= input_slv(i+output_rtype.P_bits'length-1 downto i);		i:=i+output_rtype.P_bits'length;
		output_rtype.SZ_bits		:= input_slv(i+output_rtype.SZ_bits'length-1 downto i);		i:=i+output_rtype.SZ_bits'length;
		output_rtype.LL_bits		:= input_slv(i+output_rtype.LL_bits'length-1 downto i);		i:=i+output_rtype.LL_bits'length;
		output_rtype.R_bits			:= input_slv(i+output_rtype.R_bits'length-1 downto i);		i:=i+output_rtype.R_bits'length;
		output_rtype.OpCode			:= input_slv(i+output_rtype.OpCode'length-1 downto i);		i:=i+output_rtype.OpCode'length;
		return output_rtype;
	end function hay4stk_instruction_slv_to_rtype;
	
	function hay4stk_ccr_slv_to_rtype 	(input_slv:hay4stk_ccr_slv_type) 	return hay4stk_ccr_rtype is
	variable output_rtype 	: hay4stk_ccr_rtype;
	variable i 				: integer;
	begin
		i := 0;
		output_rtype.carry				:= input_slv(i+output_rtype.carry'length-1 downto i);			i:=i+output_rtype.carry'length;
		output_rtype.overflow			:= input_slv(i+output_rtype.overflow'length-1 downto i);		i:=i+output_rtype.overflow'length;
		output_rtype.negative			:= input_slv(i+output_rtype.negative'length-1 downto i);		i:=i+output_rtype.negative'length;
		output_rtype.zero				:= input_slv(i+output_rtype.zero'length-1 downto i);			i:=i+output_rtype.zero'length;
		output_rtype.odd				:= input_slv(i+output_rtype.odd'length-1 downto i);				i:=i+output_rtype.odd'length;
		output_rtype.parity				:= input_slv(i+output_rtype.parity'length-1 downto i);			i:=i+output_rtype.parity'length;
		output_rtype.interrupt_en		:= input_slv(i+output_rtype.interrupt_en'length-1 downto i);	i:=i+output_rtype.interrupt_en'length;
		output_rtype.br_taken			:= input_slv(i+output_rtype.br_taken'length-1 downto i);		i:=i+output_rtype.br_taken'length;
		-- output_rtype.stack_dir			:= input_slv(i+output_rtype.stack_dir'length-1 downto i);		i:=i+output_rtype.stack_dir'length;
		return output_rtype;
	end function hay4stk_ccr_slv_to_rtype;
	
	function hay4stk_ccr_rtype_to_slv 	(input_rtype:hay4stk_ccr_rtype) 	return hay4stk_ccr_slv_type is
	variable output_slv : hay4stk_ccr_slv_type;
	variable i 				: integer;
	begin
		i := 0;
		output_slv(i+input_rtype.carry'length-1 downto i) 			:= input_rtype.carry;			i:=i+input_rtype.carry'length;
		output_slv(i+input_rtype.overflow'length-1 downto i)		:= input_rtype.overflow;		i:=i+input_rtype.overflow'length;
		output_slv(i+input_rtype.negative'length-1 downto i)		:= input_rtype.negative;		i:=i+input_rtype.negative'length;
		output_slv(i+input_rtype.zero'length-1 downto i)			:= input_rtype.zero;			i:=i+input_rtype.zero'length;
		output_slv(i+input_rtype.odd'length-1 downto i)				:= input_rtype.odd;				i:=i+input_rtype.odd'length;
		output_slv(i+input_rtype.parity'length-1 downto i)			:= input_rtype.parity;			i:=i+input_rtype.parity'length;
		output_slv(i+input_rtype.interrupt_en'length-1 downto i)	:= input_rtype.interrupt_en;	i:=i+input_rtype.interrupt_en'length;
		output_slv(i+input_rtype.br_taken'length-1 downto i)		:= input_rtype.br_taken;		i:=i+input_rtype.br_taken'length;
		-- output_slv(i+input_rtype.stack_dir'length-1 downto i)		:= input_rtype.stack_dir;		i:=i+input_rtype.stack_dir'length;
		return output_slv;
	end function hay4stk_ccr_rtype_to_slv;

end hay4stk_defs_pkg;